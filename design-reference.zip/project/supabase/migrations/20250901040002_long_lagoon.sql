/*
  # Owner-Client Matching System

  1. New Tables
    - `owner_likes` - Track owner swipes on client profiles
    - `client_preferences_detailed` - Enhanced client preference tracking
    - `owner_client_matches` - Specific owner-client matches
    - `swipe_analytics` - Track swipe patterns and success rates

  2. Enhanced Features
    - Super likes for premium users
    - Advanced filtering capabilities
    - Match scoring algorithm
    - Analytics tracking

  3. Security
    - Enable RLS on all new tables
    - Add policies for owners and clients
    - Ensure data privacy and access control
*/

-- Enhanced owner likes table (already exists, but ensure it has all needed columns)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'owner_likes' AND column_name = 'is_super_like'
  ) THEN
    ALTER TABLE owner_likes ADD COLUMN is_super_like boolean DEFAULT false;
  END IF;
END $$;

-- Client preferences detailed table for advanced filtering
CREATE TABLE IF NOT EXISTS client_preferences_detailed (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  
  -- Budget and timeline
  budget_min numeric DEFAULT 0,
  budget_max numeric DEFAULT 50000,
  move_in_flexibility text DEFAULT 'flexible' CHECK (move_in_flexibility IN ('urgent', 'flexible', 'long_term')),
  lease_duration_preference text DEFAULT 'any' CHECK (lease_duration_preference IN ('short_term', 'long_term', 'any')),
  
  -- Personal details
  occupation_category text,
  income_verification boolean DEFAULT false,
  credit_score_range text CHECK (credit_score_range IN ('excellent', 'good', 'fair', 'poor')),
  employment_status text CHECK (employment_status IN ('full_time', 'part_time', 'freelance', 'student', 'retired')),
  
  -- Lifestyle preferences
  lifestyle_compatibility text[] DEFAULT ARRAY[]::text[],
  pet_ownership boolean DEFAULT false,
  pet_types text[] DEFAULT ARRAY[]::text[],
  smoking_preference text DEFAULT 'non_smoker' CHECK (smoking_preference IN ('smoker', 'non_smoker', 'occasional')),
  party_frequency text DEFAULT 'never' CHECK (party_frequency IN ('never', 'rarely', 'sometimes', 'often')),
  
  -- Communication and social
  languages_spoken text[] DEFAULT ARRAY[]::text[],
  communication_style text DEFAULT 'professional' CHECK (communication_style IN ('casual', 'professional', 'formal')),
  social_media_verified boolean DEFAULT false,
  
  -- References and verification
  previous_landlord_references boolean DEFAULT false,
  background_check_completed boolean DEFAULT false,
  income_documents_provided boolean DEFAULT false,
  
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE client_preferences_detailed ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage their own detailed preferences"
  ON client_preferences_detailed
  FOR ALL
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

-- Owner client matches table for tracking specific matches
CREATE TABLE IF NOT EXISTS owner_client_matches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  client_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  listing_id uuid REFERENCES listings(id) ON DELETE SET NULL,
  
  -- Match details
  match_score numeric(5,2) DEFAULT 0,
  compatibility_factors jsonb DEFAULT '{}',
  owner_notes text,
  client_notes text,
  
  -- Status tracking
  status text DEFAULT 'potential' CHECK (status IN ('potential', 'contacted', 'viewing_scheduled', 'application_submitted', 'approved', 'rejected')),
  priority_level text DEFAULT 'normal' CHECK (priority_level IN ('low', 'normal', 'high', 'urgent')),
  
  -- Communication tracking
  last_contact_date timestamptz,
  next_follow_up_date timestamptz,
  communication_log jsonb DEFAULT '[]',
  
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  
  UNIQUE(owner_id, client_id, listing_id)
);

ALTER TABLE owner_client_matches ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Owners can manage their client matches"
  ON owner_client_matches
  FOR ALL
  TO authenticated
  USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());

CREATE POLICY "Clients can view their matches with owners"
  ON owner_client_matches
  FOR SELECT
  TO authenticated
  USING (client_id = auth.uid());

-- Swipe analytics table for tracking patterns
CREATE TABLE IF NOT EXISTS swipe_analytics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  user_role text NOT NULL CHECK (user_role IN ('client', 'owner')),
  
  -- Daily stats
  date date DEFAULT CURRENT_DATE,
  total_swipes integer DEFAULT 0,
  likes_given integer DEFAULT 0,
  passes_given integer DEFAULT 0,
  super_likes_given integer DEFAULT 0,
  
  -- Match stats
  matches_created integer DEFAULT 0,
  conversations_started integer DEFAULT 0,
  
  -- Engagement metrics
  average_time_per_profile numeric(5,2) DEFAULT 0,
  filter_usage_count integer DEFAULT 0,
  
  created_at timestamptz DEFAULT now(),
  
  UNIQUE(user_id, date)
);

ALTER TABLE swipe_analytics ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own swipe analytics"
  ON swipe_analytics
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert their own swipe analytics"
  ON swipe_analytics
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update their own swipe analytics"
  ON swipe_analytics
  FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

-- Function to calculate client-owner compatibility score
CREATE OR REPLACE FUNCTION calculate_compatibility_score(
  owner_id uuid,
  client_id uuid
) RETURNS numeric AS $$
DECLARE
  score numeric := 0;
  owner_prefs record;
  client_profile record;
BEGIN
  -- Get owner preferences
  SELECT * INTO owner_prefs
  FROM owner_client_preferences
  WHERE user_id = owner_id
  LIMIT 1;
  
  -- Get client profile
  SELECT * INTO client_profile
  FROM profiles
  WHERE id = client_id;
  
  -- Calculate score based on various factors
  IF owner_prefs IS NOT NULL AND client_profile IS NOT NULL THEN
    -- Age compatibility (20 points max)
    IF client_profile.age BETWEEN owner_prefs.min_age AND owner_prefs.max_age THEN
      score := score + 20;
    END IF;
    
    -- Budget compatibility (25 points max)
    IF client_profile.budget_max >= (
      SELECT MIN(price) FROM listings WHERE owner_id = owner_id AND is_active = true
    ) THEN
      score := score + 25;
    END IF;
    
    -- Lifestyle compatibility (20 points max)
    IF owner_prefs.compatible_lifestyle_tags && client_profile.lifestyle_tags THEN
      score := score + (
        array_length(
          array(
            SELECT unnest(owner_prefs.compatible_lifestyle_tags)
            INTERSECT
            SELECT unnest(client_profile.lifestyle_tags)
          ), 1
        ) * 5
      );
    END IF;
    
    -- Pet compatibility (15 points max)
    IF (owner_prefs.allows_pets = true AND client_profile.has_pets = true) OR
       (owner_prefs.allows_pets = false AND client_profile.has_pets = false) THEN
      score := score + 15;
    END IF;
    
    -- Verification bonus (10 points max)
    IF client_profile.verified = true THEN
      score := score + 10;
    END IF;
    
    -- References bonus (10 points max)
    IF owner_prefs.requires_references = true AND client_profile.has_references = true THEN
      score := score + 10;
    END IF;
  END IF;
  
  RETURN LEAST(score, 100); -- Cap at 100
END;
$$ LANGUAGE plpgsql;

-- Function to update swipe analytics
CREATE OR REPLACE FUNCTION update_swipe_analytics(
  p_user_id uuid,
  p_user_role text,
  p_swipe_type text
) RETURNS void AS $$
BEGIN
  INSERT INTO swipe_analytics (user_id, user_role, date, total_swipes, likes_given, passes_given, super_likes_given)
  VALUES (p_user_id, p_user_role, CURRENT_DATE, 1, 
    CASE WHEN p_swipe_type = 'like' THEN 1 ELSE 0 END,
    CASE WHEN p_swipe_type = 'pass' THEN 1 ELSE 0 END,
    CASE WHEN p_swipe_type = 'super_like' THEN 1 ELSE 0 END
  )
  ON CONFLICT (user_id, date)
  DO UPDATE SET
    total_swipes = swipe_analytics.total_swipes + 1,
    likes_given = swipe_analytics.likes_given + CASE WHEN p_swipe_type = 'like' THEN 1 ELSE 0 END,
    passes_given = swipe_analytics.passes_given + CASE WHEN p_swipe_type = 'pass' THEN 1 ELSE 0 END,
    super_likes_given = swipe_analytics.super_likes_given + CASE WHEN p_swipe_type = 'super_like' THEN 1 ELSE 0 END;
END;
$$ LANGUAGE plpgsql;

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_client_preferences_detailed_user_id ON client_preferences_detailed(user_id);
CREATE INDEX IF NOT EXISTS idx_owner_client_matches_owner_id ON owner_client_matches(owner_id);
CREATE INDEX IF NOT EXISTS idx_owner_client_matches_client_id ON owner_client_matches(client_id);
CREATE INDEX IF NOT EXISTS idx_owner_client_matches_status ON owner_client_matches(status);
CREATE INDEX IF NOT EXISTS idx_swipe_analytics_user_date ON swipe_analytics(user_id, date);
CREATE INDEX IF NOT EXISTS idx_owner_likes_super_like ON owner_likes(is_super_like) WHERE is_super_like = true;