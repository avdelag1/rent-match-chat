import React, { createContext, useContext, useEffect, useState } from 'react';

export type ColorMode = 'normal' | 'dark' | 'amber';

interface ThemeContextType {
  colorMode: ColorMode;
  setColorMode: (mode: ColorMode) => void;
  toggleColorMode: () => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [colorMode, setColorModeState] = useState<ColorMode>('normal');

  useEffect(() => {
    // Load saved theme from localStorage
    const savedMode = localStorage.getItem('tinderent_color_mode') as ColorMode;
    if (savedMode && ['normal', 'dark', 'amber'].includes(savedMode)) {
      setColorModeState(savedMode);
      applyThemeToDocument(savedMode);
    }
  }, []);

  const setColorMode = (mode: ColorMode) => {
    setColorModeState(mode);
    localStorage.setItem('tinderent_color_mode', mode);
    applyThemeToDocument(mode);
  };

  const toggleColorMode = () => {
    const modes: ColorMode[] = ['normal', 'dark', 'amber'];
    const currentIndex = modes.indexOf(colorMode);
    const nextIndex = (currentIndex + 1) % modes.length;
    setColorMode(modes[nextIndex]);
  };

  const applyThemeToDocument = (mode: ColorMode) => {
    const root = document.documentElement;
    
    // Remove existing theme classes
    root.classList.remove('theme-normal', 'theme-dark', 'theme-amber');
    
    // Add new theme class
    root.classList.add(`theme-${mode}`);
  };

  const value = {
    colorMode,
    setColorMode,
    toggleColorMode
  };

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
};