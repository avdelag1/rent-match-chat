import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase, isDemoMode, Profile } from '../lib/supabase';
import toast from 'react-hot-toast';

interface AuthContextType {
  user: User | null;
  profile: Profile | null;
  session: Session | null;
  loading: boolean;
  signUp: (email: string, password: string, userData: Partial<Profile>) => Promise<void>;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  updateProfile: (updates: Partial<Profile>) => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    console.log('AuthContext: Initializing...');
    
    // If in demo mode, initialize with demo data
    if (isDemoMode) {
      console.log('AuthContext: Running in demo mode');
      initializeDemoMode();
      return;
    }

    // Get initial session
    const initializeAuth = async () => {
      try {
        const { data: { session: initialSession }, error } = await supabase.auth.getSession();
        
        if (error) {
          console.error('Error getting session:', error);
          setLoading(false);
          return;
        }

        if (initialSession?.user) {
          console.log('AuthContext: Found existing session for user:', initialSession.user.id);
          setSession(initialSession);
          setUser(initialSession.user);
          await loadUserProfile(initialSession.user.id);
        } else {
          console.log('AuthContext: No existing session found');
        }
      } catch (error) {
        console.error('AuthContext: Error during initialization:', error);
      } finally {
        setLoading(false);
      }
    };

    initializeAuth();

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        console.log('AuthContext: Auth state changed:', event, session?.user?.id);
        
        setSession(session);
        setUser(session?.user ?? null);

        if (session?.user) {
          await loadUserProfile(session.user.id);
        } else {
          setProfile(null);
        }
        
        setLoading(false);
      }
    );

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const initializeDemoMode = () => {
    // Check for existing demo session
    const demoSession = localStorage.getItem('demo_session');
    if (demoSession) {
      try {
        const sessionData = JSON.parse(demoSession);
        setUser(sessionData.user);
        setProfile(sessionData.profile);
        console.log('AuthContext: Demo session restored');
      } catch (error) {
        console.error('Error parsing demo session:', error);
        localStorage.removeItem('demo_session');
      }
    }
    setLoading(false);
  };

  const loadUserProfile = async (userId: string) => {
    if (isDemoMode) return;
    
    try {
      console.log('AuthContext: Loading profile for user:', userId);
      const { data: userProfile, error } = await supabase!
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();
      
      if (error) throw error;
      
      if (userProfile) {
        console.log('AuthContext: Profile loaded:', userProfile.role);
        setProfile(userProfile);
      } else {
        console.log('AuthContext: No profile found for user');
        setProfile(null);
      }
    } catch (error) {
      console.error('AuthContext: Error loading profile:', error);
      setProfile(null);
    }
  };

  const signUp = async (email: string, password: string, userData: Partial<Profile>) => {
    console.log('AuthContext: Starting sign up for role:', userData.role);
    setLoading(true);

    // Demo mode sign up
    if (isDemoMode) {
      try {
        const demoUser = {
          id: `demo-${Date.now()}`,
          email,
          created_at: new Date().toISOString()
        };

        const demoProfile: Profile = {
          id: demoUser.id,
          email,
          full_name: userData.full_name || 'Demo User',
          role: userData.role || 'client',
          phone: userData.phone,
          location: userData.location,
          age: userData.age,
          bio: userData.bio,
          is_active: true,
          onboarding_completed: userData.role === 'owner',
          verified: false,
          images: [],
          interests: [],
          lifestyle_tags: [],
          budget_min: userData.role === 'client' ? 1000 : undefined,
          budget_max: userData.role === 'client' ? 5000 : undefined,
          preferred_property_types: userData.role === 'client' ? [] : undefined,
          preferred_locations: userData.role === 'client' ? [] : undefined,
          created_at: new Date().toISOString()
        };

        // Store in localStorage
        localStorage.setItem('demo_session', JSON.stringify({
          user: demoUser,
          profile: demoProfile
        }));

        setUser(demoUser as any);
        setProfile(demoProfile);
        toast.success('Demo account created successfully!');
        return;
      } catch (error: any) {
        console.error('Demo sign up error:', error);
        toast.error('Failed to create demo account');
        throw error;
      } finally {
        setLoading(false);
      }
    }

    try {
      const { data: authData, error: authError } = await supabase!.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: userData.full_name,
            role: userData.role
          }
        }
      });

      if (authError) throw authError;

      if (!authData.user) {
        throw new Error('Failed to create user account');
      }

      console.log('AuthContext: User created:', authData.user.id);

      // Create user profile in profiles table
      const profileData: Partial<Profile> = {
        id: authData.user.id,
        email: authData.user.email,
        full_name: userData.full_name,
        role: userData.role,
        phone: userData.phone,
        location: userData.location,
        age: userData.age,
        bio: userData.bio,
        is_active: true,
        onboarding_completed: userData.role === 'owner', // Owners skip onboarding
        verified: false,
        images: [],
        interests: [],
        lifestyle_tags: [],
        budget_min: userData.role === 'client' ? 1000 : undefined,
        budget_max: userData.role === 'client' ? 5000 : undefined,
        preferred_property_types: userData.role === 'client' ? [] : undefined,
        preferred_locations: userData.role === 'client' ? [] : undefined
      };

      const { data: newProfile, error: profileError } = await supabase!
        .from('profiles')
        .insert(profileData)
        .select()
        .single();

      if (profileError) throw profileError;
      console.log('AuthContext: Profile created:', newProfile.role);

      setUser(authData.user);
      setProfile(newProfile);

      toast.success('Account created successfully!');
      
    } catch (error: any) {
      console.error('AuthContext: Sign up error:', error);
      toast.error(error.message || 'Failed to create account');
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const signIn = async (email: string, password: string) => {
    console.log('AuthContext: Starting sign in for email:', email);
    setLoading(true);
    
    try {
      // Demo mode sign in
      if (isDemoMode) {
        console.log('AuthContext: Using demo mode sign in');
        try {
          // Check for existing demo session
          const demoSession = localStorage.getItem('demo_session');
          if (demoSession) {
            const sessionData = JSON.parse(demoSession);
            if (sessionData.user.email === email) {
              setUser(sessionData.user);
              setProfile(sessionData.profile);
              toast.success('Demo sign in successful!');
              return;
            }
          }
          
          // Create new demo session for sign in
          const demoUser = {
            id: `demo-${Date.now()}`,
            email,
            created_at: new Date().toISOString()
          };

          const demoProfile: Profile = {
            id: demoUser.id,
            email,
            full_name: 'Demo User',
            role: 'client',
            is_active: true,
            onboarding_completed: false,
            verified: false,
            images: [],
            interests: [],
            lifestyle_tags: [],
            budget_min: 1000,
            budget_max: 5000,
            preferred_property_types: [],
            preferred_locations: [],
            created_at: new Date().toISOString()
          };

          localStorage.setItem('demo_session', JSON.stringify({
            user: demoUser,
            profile: demoProfile
          }));

          setUser(demoUser as any);
          setProfile(demoProfile);
          toast.success('Demo sign in successful!');
          return;
        } catch (error: any) {
          console.error('Demo sign in error:', error);
          toast.error('Failed to sign in to demo');
          throw error;
        }
      }

      // Only attempt Supabase sign in if not in demo mode
      if (!supabase) {
        throw new Error('Supabase is not configured');
      }

      const { data: authData, error: authError } = await supabase.auth.signInWithPassword({
        email,
        password
      });

      if (authError) throw authError;

      if (!authData.user) {
        throw new Error('Failed to sign in');
      }

      console.log('AuthContext: User signed in:', authData.user.id);

      // Load user profile
      await loadUserProfile(authData.user.id);
      
      toast.success('Welcome back!');
      
    } catch (error: any) {
      console.error('AuthContext: Sign in error:', error);
      toast.error(error.message || 'Failed to sign in');
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const signOut = async () => {
    console.log('AuthContext: Starting sign out');
    setLoading(true);
    
    // Demo mode sign out
    if (isDemoMode) {
      localStorage.removeItem('demo_session');
      setUser(null);
      setProfile(null);
      setSession(null);
      toast.success('Demo sign out successful');
      setLoading(false);
      return;
    }
    
    try {
      const { error } = await supabase!.auth.signOut();
      if (error) throw error;
      
      setUser(null);
      setProfile(null);
      setSession(null);
      
      toast.success('Signed out successfully');
      console.log('AuthContext: Sign out complete');
      
    } catch (error: any) {
      console.error('AuthContext: Sign out error:', error);
      toast.error(error.message || 'Failed to sign out');
    } finally {
      setLoading(false);
    }
  };

  const updateProfile = async (updates: Partial<Profile>) => {
    console.log('AuthContext: Updating profile with:', updates);
    
    // Demo mode update
    if (isDemoMode) {
      try {
        const updatedProfile = { ...profile, ...updates };
        setProfile(updatedProfile);
        
        // Update localStorage
        const demoSession = localStorage.getItem('demo_session');
        if (demoSession) {
          const sessionData = JSON.parse(demoSession);
          sessionData.profile = updatedProfile;
          localStorage.setItem('demo_session', JSON.stringify(sessionData));
        }
        
        toast.success('Demo profile updated successfully');
        return;
      } catch (error: any) {
        console.error('Demo update error:', error);
        toast.error('Failed to update demo profile');
        throw error;
      }
    }
    
    try {
      if (!user) throw new Error('No user found');

      const { data: updatedProfile, error } = await supabase!
        .from('profiles')
        .update({
          ...updates,
          updated_at: new Date().toISOString()
        })
        .eq('id', user.id)
        .select()
        .single();

      if (error) throw error;
      
      setProfile(updatedProfile);
      toast.success('Profile updated successfully');
      console.log('AuthContext: Profile update complete');
      
    } catch (error: any) {
      console.error('AuthContext: Update profile error:', error);
      toast.error(error.message || 'Failed to update profile');
      throw error;
    }
  };

  const refreshProfile = async () => {
    if (!user) return;
    
    if (isDemoMode) return;
    
    try {
      await loadUserProfile(user.id);
    } catch (error) {
      console.error('Error refreshing profile:', error);
    }
  };

  const value = {
    user,
    profile,
    session,
    loading,
    signUp,
    signIn,
    signOut,
    updateProfile,
    refreshProfile,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};