import { useState, useCallback } from 'react';
import { uploadMultiplePhotos, PhotoUploadOptions, UploadResult } from '../lib/photoUpload';
import toast from 'react-hot-toast';

interface UsePhotoUploadOptions extends PhotoUploadOptions {
  onSuccess?: (results: UploadResult[]) => void;
  onError?: (error: Error) => void;
}

export const usePhotoUpload = (options: UsePhotoUploadOptions) => {
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState({ completed: 0, total: 0, currentFile: '' });

  const uploadPhotos = useCallback(async (files: File[]) => {
    if (files.length === 0) return;

    setUploading(true);
    setProgress({ completed: 0, total: files.length, currentFile: '' });

    try {
      const results = await uploadMultiplePhotos(
        files,
        options,
        (progressData) => {
          setProgress({
            completed: progressData.completed,
            total: progressData.total,
            currentFile: progressData.currentFile || ''
          });
        }
      );

      options.onSuccess?.(results);
      toast.success(`Successfully uploaded ${results.length} photo${results.length !== 1 ? 's' : ''}`);
      
      return results;
    } catch (error: any) {
      options.onError?.(error);
      toast.error(error.message || 'Upload failed');
      throw error;
    } finally {
      setUploading(false);
      setProgress({ completed: 0, total: 0, currentFile: '' });
    }
  }, [options]);

  const reset = useCallback(() => {
    setUploading(false);
    setProgress({ completed: 0, total: 0, currentFile: '' });
  }, []);

  return {
    uploadPhotos,
    uploading,
    progress,
    reset
  };
};