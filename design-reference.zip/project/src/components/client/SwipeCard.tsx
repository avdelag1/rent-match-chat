import React, { useState } from 'react';
import { motion, PanInfo, useMotionValue, useTransform } from 'framer-motion';
import { Heart, X, MapPin, Bed, Bath, Square, Star, Info } from 'lucide-react';
import { Listing } from '../../lib/supabase';

interface SwipeCardProps {
  listing: Listing;
  onSwipe: (direction: 'left' | 'right') => void;
  onTap: () => void;
  onSuperLike?: () => void;
  isPremium?: boolean;
}

const SwipeCard: React.FC<SwipeCardProps> = ({ 
  listing, 
  onSwipe, 
  onTap, 
  onSuperLike,
  isPremium = false 
}) => {
  const [exitX, setExitX] = useState(0);
  const x = useMotionValue(0);
  const rotate = useTransform(x, [-200, 200], [-30, 30]);
  const opacity = useTransform(x, [-200, -150, 0, 150, 200], [0, 1, 1, 1, 0]);

  const handleDragEnd = (event: any, info: PanInfo) => {
    const threshold = 100;
    
    if (info.offset.x > threshold) {
      setExitX(200);
      onSwipe('right');
    } else if (info.offset.x < -threshold) {
      setExitX(-200);
      onSwipe('left');
    }
  };

  const mainImage = listing.images?.[0] || 'https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg';

  return (
    <motion.div
      className="absolute inset-0 cursor-grab active:cursor-grabbing"
      style={{ x, rotate, opacity }}
      drag="x"
      dragConstraints={{ left: 0, right: 0 }}
      onDragEnd={handleDragEnd}
      animate={exitX !== 0 ? { x: exitX } : {}}
    >
      <div className="w-full h-full bg-white rounded-3xl shadow-2xl overflow-hidden relative flex flex-col">
        {/* Main Image Section - 60% height */}
        <div className="relative h-[60%] flex-shrink-0">
          <img
            src={mainImage}
            alt={listing.title}
            className="w-full h-full object-cover"
          />
          
          {/* Gradient Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/20" />
          
          {/* Featured Badge */}
          {listing.is_featured && (
            <div className="absolute top-4 right-4 bg-yellow-400 text-black px-3 py-1 rounded-full text-sm font-semibold flex items-center space-x-1 shadow-lg">
              <Star className="w-4 h-4" />
              <span>Featured</span>
            </div>
          )}

          {/* Price Badge */}
          <div className="absolute top-4 left-4 bg-white/95 backdrop-blur-sm px-4 py-2 rounded-full shadow-lg">
            <span className="text-xl font-bold text-gray-800">
              ${listing.price?.toLocaleString() || '0'}
              <span className="text-sm text-gray-600 ml-1">
                /{listing.listing_type === 'rent' ? 'month' : 'total'}
              </span>
            </span>
          </div>

          {/* Info Button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              onTap();
            }}
            className="absolute bottom-4 right-4 w-12 h-12 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center shadow-lg hover:bg-white transition-all"
          >
            <Info className="w-5 h-5 text-gray-700" />
          </button>
        </div>

        {/* Property Info Section - 25% height */}
        <div className="flex-1 p-6 flex flex-col justify-between min-h-0">
          <div className="flex-1">
            <h3 className="text-2xl font-bold text-gray-800 mb-2 line-clamp-2 leading-tight">
              {listing.title}
            </h3>
            
            <div className="flex items-center text-gray-600 mb-4">
              <MapPin className="w-4 h-4 mr-2 flex-shrink-0" />
              <span className="text-sm truncate">{listing.address}</span>
            </div>

            {/* Property Details */}
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                {listing.beds && (
                  <div className="flex items-center space-x-1 text-gray-600">
                    <Bed className="w-4 h-4" />
                    <span className="text-sm font-medium">{listing.beds}</span>
                  </div>
                )}
                {listing.baths && (
                  <div className="flex items-center space-x-1 text-gray-600">
                    <Bath className="w-4 h-4" />
                    <span className="text-sm font-medium">{listing.baths}</span>
                  </div>
                )}
                {listing.square_footage && (
                  <div className="flex items-center space-x-1 text-gray-600">
                    <Square className="w-4 h-4" />
                    <span className="text-sm font-medium">{listing.square_footage} sqft</span>
                  </div>
                )}
              </div>

              {/* Property Type Badge */}
              <div className="bg-gray-100 px-3 py-1 rounded-full">
                <span className="text-sm text-gray-700 capitalize font-medium">
                  {listing.property_type}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons Section - 15% height */}
        <div className="h-[15%] min-h-[90px] bg-white border-t border-gray-100 flex items-center justify-center px-8 py-4">
          <div className="flex items-center justify-center space-x-8 w-full max-w-xs">
            {/* Dislike Button */}
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              transition={{ type: "spring", stiffness: 400, damping: 17 }}
              onClick={(e) => {
                e.stopPropagation();
                onSwipe('left');
              }}
              className="w-16 h-16 bg-gray-100 hover:bg-gray-200 rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-all duration-200 border-2 border-gray-200 active:scale-90"
            >
              <X className="w-7 h-7 text-gray-600" />
            </motion.button>

            {/* Super Like Button (Premium only) */}
            {isPremium && onSuperLike && (
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                transition={{ type: "spring", stiffness: 400, damping: 17 }}
                onClick={(e) => {
                  e.stopPropagation();
                  onSuperLike();
                }}
                className="w-14 h-14 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-all duration-200 active:scale-90"
              >
                <Star className="w-6 h-6 text-white" />
              </motion.button>
            )}

            {/* Like Button */}
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              transition={{ type: "spring", stiffness: 400, damping: 17 }}
              onClick={(e) => {
                e.stopPropagation();
                onSwipe('right');
              }}
              className="w-16 h-16 bg-gradient-to-r from-pink-500 to-red-500 hover:from-pink-600 hover:to-red-600 rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-all duration-200 active:scale-90"
            >
              <Heart className="w-7 h-7 text-white" />
            </motion.button>
          </div>
        </div>

        {/* Swipe Indicators */}
        <motion.div
          className="absolute top-1/2 left-8 transform -translate-y-1/2 bg-red-500 text-white px-6 py-3 rounded-full font-bold text-xl border-4 border-white shadow-lg"
          style={{
            opacity: useTransform(x, [-150, -50], [1, 0])
          }}
        >
          NOPE
        </motion.div>

        <motion.div
          className="absolute top-1/2 right-8 transform -translate-y-1/2 bg-green-500 text-white px-6 py-3 rounded-full font-bold text-xl border-4 border-white shadow-lg"
          style={{
            opacity: useTransform(x, [50, 150], [0, 1])
          }}
        >
          LIKE
        </motion.div>
      </div>
    </motion.div>
  );
};

export default SwipeCard;