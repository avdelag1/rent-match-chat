import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, MapPin, Bed, Bath, Square, Calendar, DollarSign, Check, Heart, Share } from 'lucide-react';
import { Listing } from '../../lib/supabase';

interface PropertyDetailsProps {
  listing: Listing;
  onClose: () => void;
}

const PropertyDetails: React.FC<PropertyDetailsProps> = ({ listing, onClose }) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const images = listing.images || [
    'https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg'
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 z-50 flex items-end"
      onClick={onClose}
    >
      <motion.div
        initial={{ y: '100%' }}
        animate={{ y: 0 }}
        exit={{ y: '100%' }}
        transition={{ type: 'spring', damping: 25, stiffness: 200 }}
        className="w-full bg-white rounded-t-3xl max-h-[90vh] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200">
          <h2 className="text-xl font-bold text-gray-800">Property Details</h2>
          <button
            onClick={onClose}
            className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center"
          >
            <X className="w-5 h-5 text-gray-600" />
          </button>
        </div>

        <div className="overflow-y-auto max-h-[calc(90vh-80px)]">
          {/* Image Gallery */}
          <div className="relative h-80">
            <img
              src={images[currentImageIndex]}
              alt={listing.title}
              className="w-full h-full object-cover"
            />
            
            {/* Image Navigation */}
            {images.length > 1 && (
              <>
                <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
                  {images.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentImageIndex(index)}
                      className={`w-2 h-2 rounded-full transition-all ${
                        index === currentImageIndex ? 'bg-white' : 'bg-white/50'
                      }`}
                    />
                  ))}
                </div>

                <button
                  onClick={() => setCurrentImageIndex(prev => prev > 0 ? prev - 1 : images.length - 1)}
                  className="absolute left-4 top-1/2 transform -translate-y-1/2 w-10 h-10 bg-black/30 rounded-full flex items-center justify-center text-white"
                >
                  ←
                </button>

                <button
                  onClick={() => setCurrentImageIndex(prev => prev < images.length - 1 ? prev + 1 : 0)}
                  className="absolute right-4 top-1/2 transform -translate-y-1/2 w-10 h-10 bg-black/30 rounded-full flex items-center justify-center text-white"
                >
                  →
                </button>
              </>
            )}

            {/* Action Buttons */}
            <div className="absolute top-4 right-4 flex space-x-2">
              <button className="w-10 h-10 bg-white/90 rounded-full flex items-center justify-center">
                <Share className="w-5 h-5 text-gray-700" />
              </button>
              <button className="w-10 h-10 bg-white/90 rounded-full flex items-center justify-center">
                <Heart className="w-5 h-5 text-red-500" />
              </button>
            </div>
          </div>

          {/* Property Info */}
          <div className="p-6">
            {/* Title and Price */}
            <div className="mb-6">
              <h1 className="text-3xl font-bold text-gray-800 mb-2">
                {listing.title}
              </h1>
              <div className="flex items-center justify-between">
                <div className="flex items-center text-gray-600">
                  <MapPin className="w-5 h-5 mr-2" />
                  <span>{listing.address}</span>
                </div>
                <div className="text-right">
                  <div className="text-3xl font-bold text-orange-500">
                    ${listing.price?.toLocaleString() || '0'}
                  </div>
                  <div className="text-sm text-gray-600">
                    {listing.listing_type === 'rent' ? 'per month' : 'total price'}
                  </div>
                </div>
              </div>
            </div>

            {/* Property Stats */}
            <div className="grid grid-cols-3 gap-4 mb-6">
              {listing.beds && (
                <div className="text-center p-4 bg-gray-50 rounded-xl">
                  <Bed className="w-6 h-6 mx-auto mb-2 text-gray-600" />
                  <div className="font-semibold text-gray-800">{listing.beds}</div>
                  <div className="text-sm text-gray-600">Bedrooms</div>
                </div>
              )}
              {listing.baths && (
                <div className="text-center p-4 bg-gray-50 rounded-xl">
                  <Bath className="w-6 h-6 mx-auto mb-2 text-gray-600" />
                  <div className="font-semibold text-gray-800">{listing.baths}</div>
                  <div className="text-sm text-gray-600">Bathrooms</div>
                </div>
              )}
              {listing.square_footage && (
                <div className="text-center p-4 bg-gray-50 rounded-xl">
                  <Square className="w-6 h-6 mx-auto mb-2 text-gray-600" />
                  <div className="font-semibold text-gray-800">{listing.square_footage}</div>
                  <div className="text-sm text-gray-600">Sq Ft</div>
                </div>
              )}
            </div>

            {/* Description */}
            <div className="mb-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-3">Description</h3>
              <p className="text-gray-600 leading-relaxed">{listing.description}</p>
            </div>

            {/* Amenities */}
            {listing.amenities && listing.amenities.length > 0 && (
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-3">Amenities</h3>
                <div className="grid grid-cols-2 gap-2">
                  {listing.amenities.map((amenity, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <Check className="w-4 h-4 text-green-500" />
                      <span className="text-gray-700 capitalize">{amenity}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Additional Details */}
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <Calendar className="w-4 h-4 text-gray-500" />
                  <span className="text-sm text-gray-600">
                    Available: {listing.availability_date ? new Date(listing.availability_date).toLocaleDateString() : 'Now'}
                  </span>
                </div>
                {listing.deposit_amount && (
                  <div className="flex items-center space-x-2">
                    <DollarSign className="w-4 h-4 text-gray-500" />
                    <span className="text-sm text-gray-600">
                      Deposit: ${listing.deposit_amount.toLocaleString()}
                    </span>
                  </div>
                )}
              </div>
              <div className="space-y-3">
                <div className="text-sm text-gray-600">
                  <span className="font-medium">Furnished:</span> {listing.furnished ? 'Yes' : 'No'}
                </div>
                <div className="text-sm text-gray-600">
                  <span className="font-medium">Pet Friendly:</span> {listing.pet_friendly ? 'Yes' : 'No'}
                </div>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default PropertyDetails;