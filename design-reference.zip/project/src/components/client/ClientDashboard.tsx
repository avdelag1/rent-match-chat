import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Filter, MessageCircle, User, Settings, Heart, Zap, Bell } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useTheme } from '../../contexts/ThemeContext';
import { supabase, Listing } from '../../lib/supabase';
import SwipeCard from './SwipeCard';
import PropertyDetails from './PropertyDetails';
import FilterModal from './FilterModal';
import MatchesList from './MatchesList';
import ProfileSettings from './ProfileSettings';
import PremiumModal from '../subscription/PremiumModal';
import NotificationCenter from '../notifications/NotificationCenter';
import { useNotifications } from '../../hooks/useNotifications';
import ClientSettings from './ClientSettings';
import EnhancedOnboarding from './EnhancedOnboarding';
import ColorModeToggle from '../common/ColorModeToggle';
import toast from 'react-hot-toast';

const ClientDashboard: React.FC = () => {
  const { profile, signOut } = useAuth();
  const { colorMode } = useTheme();
  const { unreadCount } = useNotifications();
  const [listings, setListings] = useState<Listing[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showPropertyDetails, setShowPropertyDetails] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [showMatches, setShowMatches] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [showPremium, setShowPremium] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [loading, setLoading] = useState(true);
  const [swipeCount, setSwipeCount] = useState(0);
  const [filters, setFilters] = useState<any>({});

  const currentListing = listings[currentIndex];
  const dailySwipeLimit = 50; // Free users get 50 swipes per day

  // Check if onboarding is needed
  if (profile && !profile.onboarding_completed) {
    return <EnhancedOnboarding onComplete={() => window.location.reload()} />;
  }

  useEffect(() => {
    if (profile) {
      fetchListings();
      fetchTodaySwipeCount();
    }
  }, [profile, filters]);

  const fetchListings = async () => {
    if (!profile) return;

    try {
      let query = supabase
        .from('listings')
        .select(`
          *,
          owner:profiles(*)
        `)
        .eq('is_active', true)
        .neq('owner_id', profile?.id); // Don't show own listings

      // Apply filters
      if (filters.priceRange) {
        query = query.gte('price', filters.priceRange[0]).lte('price', filters.priceRange[1]);
      }
      if (filters.propertyType) {
        query = query.eq('property_type', filters.propertyType);
      }
      if (filters.bedrooms) {
        query = query.gte('beds', parseInt(filters.bedrooms));
      }
      if (filters.bathrooms) {
        query = query.gte('baths', parseInt(filters.bathrooms));
      }

      const { data, error } = await query.order('created_at', { ascending: false });

      if (error) throw error;
      setListings(data || []);
    } catch (error) {
      console.error('Error fetching listings:', error);
      toast.error('Failed to load properties');
    } finally {
      setLoading(false);
    }
  };

  const fetchTodaySwipeCount = async () => {
    if (!profile) return;

    try {
      const today = new Date().toISOString().split('T')[0];
      const { count } = await supabase
        .from('swipes')
        .select('*', { count: 'exact' })
        .eq('user_id', profile.id)
        .gte('created_at', today);

      setSwipeCount(count || 0);
    } catch (error) {
      console.error('Error fetching swipe count:', error);
      setSwipeCount(0);
    }
  };

  const handleSwipe = async (direction: 'left' | 'right') => {
    if (!currentListing || !profile) return;

    // Check swipe limit
    if (profile.package !== 'premium' && profile.package !== 'unlimited' && swipeCount >= dailySwipeLimit) {
      setShowPremium(true);
      return;
    }

    try {
      // Record the swipe
      const { error } = await supabase
        .from('swipes')
        .insert({
          user_id: profile.id,
          target_id: currentListing.id,
          target_type: 'listing',
          action: direction === 'right' ? 'like' : 'pass'
        });

      if (error) throw error;

      setSwipeCount(prev => prev + 1);

      // Check for match if liked
      if (direction === 'right') {
        await checkForMatch(currentListing);
      }

      // Move to next property
      setCurrentIndex(prev => prev + 1);
    } catch (error) {
      console.error('Error recording swipe:', error);
      toast.error('Failed to record swipe');
    }
  };

  const checkForMatch = async (listing: Listing) => {
    if (!profile) return;

    try {
      // Check if owner has liked this client back
      const { data: ownerLike } = await supabase
        .from('swipes')
        .select('*')
        .eq('user_id', listing.owner_id)
        .eq('target_id', profile?.id)
        .eq('target_type', 'profile')
        .eq('action', 'like')
        .maybeSingle();

      if (ownerLike) {
        // Create match
        const { error } = await supabase
          .from('matches')
          .insert({
            client_id: profile?.id,
            owner_id: listing.owner_id,
            listing_id: listing.id,
            is_mutual: true
          });

        if (!error) {
          toast.success('🎉 It\'s a match!');
        }
      }
    } catch (error) {
      console.error('Error checking for match:', error);
    }
  };

  const handleSuperLike = async (listing: Listing) => {
    if (!profile) return;

    // Check if user has premium access
    if (profile.package !== 'premium' && profile.package !== 'unlimited') {
      setShowPremium(true);
      return;
    }

    try {
      const { error } = await supabase
        .from('swipes')
        .insert({
          user_id: profile.id,
          target_id: listing.id,
          target_type: 'listing',
          action: 'superlike'
        });

      if (error) throw error;

      setSwipeCount(prev => prev + 1);
      await checkForMatch(listing);
      setCurrentIndex(prev => prev + 1);
      toast.success('⭐ Super Like sent!');
    } catch (error) {
      console.error('Error sending super like:', error);
      toast.error('Failed to send super like');
    }
  };

  const handleApplyFilters = (newFilters: any) => {
    setFilters(newFilters);
    setCurrentIndex(0);
    setShowFilters(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-pink-500 via-red-500 to-orange-500 flex items-center justify-center">
        <div className="text-white text-center">
          <div className="w-16 h-16 border-4 border-white border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-xl">Loading properties...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-500 via-red-500 to-orange-500">
      {/* Header */}
      <div className="flex items-center justify-between p-4 pt-12">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center">
            <span className="text-xl">🔥</span>
          </div>
          <div className="text-white">
            <h1 className="text-xl font-bold">Tinderent</h1>
            <p className="text-sm opacity-80">
              {swipeCount}/{dailySwipeLimit} swipes today
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => setShowNotifications(true)}
            className="relative w-10 h-10 bg-white/20 rounded-full flex items-center justify-center"
          >
            <Bell className="w-5 h-5 text-white" />
            {unreadCount > 0 && (
              <span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs font-semibold flex items-center space-x-1">
                <Star className="w-3 h-3" />
                {unreadCount}
              </span>
            )}
          </button>
          
          <ColorModeToggle size="md" showLabel={false} />
          
          <button
            onClick={() => setShowFilters(true)}
            className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center"
          >
            <Filter className="w-5 h-5 text-white" />
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="px-4 pb-24">
        {currentIndex < listings.length ? (
          <div className="relative h-[650px] max-w-sm mx-auto">
            <AnimatePresence>
              {listings.slice(currentIndex, currentIndex + 3).map((listing, index) => (
                <motion.div
                  key={listing.id}
                  className="absolute inset-0"
                  style={{ zIndex: 3 - index }}
                  initial={{ scale: 1 - index * 0.05, y: index * 10 }}
                  animate={{ scale: 1 - index * 0.05, y: index * 10 }}
                >
                  {index === 0 ? (
                    <SwipeCard
                      listing={listing}
                      onSwipe={handleSwipe}
                      onTap={() => setShowPropertyDetails(true)}
                      onSuperLike={() => handleSuperLike(listing)}
                      isPremium={profile?.package === 'premium' || profile?.package === 'unlimited'}
                    />
                  ) : (
                    <div className="w-full h-full bg-white rounded-3xl shadow-xl overflow-hidden">
                      <img
                        src={listing.images?.[0] || 'https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg'}
                        alt={listing.title}
                        className="w-full h-3/5 object-cover"
                      />
                      <div className="p-6">
                        <h3 className="text-xl font-bold text-gray-800 mb-2">
                          {listing.title}
                        </h3>
                        <div className="flex items-center text-gray-600">
                          <span className="text-sm">{listing.address}</span>
                        </div>
                      </div>
                    </div>
                  )}
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        ) : (
          <div className="text-center text-white py-20">
            <Heart className="w-16 h-16 mx-auto mb-4 opacity-50" />
            <h2 className="text-2xl font-bold mb-2">No more properties!</h2>
            <p className="opacity-80 mb-6">Check back later for new listings</p>
            <button
              onClick={() => {
                setCurrentIndex(0);
                fetchListings();
              }}
              className="bg-white text-orange-500 px-6 py-3 rounded-full font-semibold"
            >
              Refresh
            </button>
          </div>
        )}
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-3">
        <div className="flex justify-around items-center max-w-sm mx-auto">
          <button
            onClick={() => setShowProfile(true)}
            className="flex flex-col items-center space-y-1 text-gray-600 hover:text-orange-500 transition-colors"
          >
            <User className="w-6 h-6" />
            <span className="text-xs">Profile</span>
          </button>

          <button
            onClick={() => setShowMatches(true)}
            className="flex flex-col items-center space-y-1 text-gray-600 hover:text-orange-500 transition-colors"
          >
            <MessageCircle className="w-6 h-6" />
            <span className="text-xs">Matches</span>
          </button>

          <button
            onClick={() => setShowPremium(true)}
            className="flex flex-col items-center space-y-1 text-yellow-500 hover:text-yellow-600 transition-colors"
          >
            <Zap className="w-6 h-6" />
            <span className="text-xs">Premium</span>
          </button>

          <button
            onClick={() => setShowSettings(true)}
            className="flex flex-col items-center space-y-1 text-gray-600 hover:text-orange-500 transition-colors"
          >
            <Settings className="w-6 h-6" />
            <span className="text-xs">Settings</span>
          </button>
        </div>
      </div>

      {/* Modals */}
      <AnimatePresence>
        {showPropertyDetails && currentListing && (
          <PropertyDetails
            listing={currentListing}
            onClose={() => setShowPropertyDetails(false)}
          />
        )}

        {showFilters && (
          <FilterModal
            onClose={() => setShowFilters(false)}
            onApplyFilters={handleApplyFilters}
          />
        )}

        {showMatches && (
          <MatchesList onClose={() => setShowMatches(false)} />
        )}

        {showProfile && (
          <ProfileSettings 
            onClose={() => setShowProfile(false)}
            onShowPremium={() => setShowPremium(true)}
          />
        )}

        {showPremium && (
          <PremiumModal
            userType="client"
            onClose={() => setShowPremium(false)}
          />
        )}

        {showNotifications && (
          <NotificationCenter
            onClose={() => setShowNotifications(false)}
          />
        )}

        {showSettings && (
          <ClientSettings
            onClose={() => setShowSettings(false)}
          />
        )}
      </AnimatePresence>
    </div>
  );
};

export default ClientDashboard;