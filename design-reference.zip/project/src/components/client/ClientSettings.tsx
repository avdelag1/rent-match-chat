import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  X, 
  User, 
  Bell, 
  Shield, 
  CreditCard, 
  MapPin, 
  Filter,
  Moon,
  Sun,
  Globe,
  HelpCircle,
  LogOut,
  ChevronRight,
  Palette
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useTheme } from '../../contexts/ThemeContext';
import PremiumModal from '../subscription/PremiumModal';
import ColorModeToggle from '../common/ColorModeToggle';

interface ClientSettingsProps {
  onClose: () => void;
}

const ClientSettings: React.FC<ClientSettingsProps> = ({ onClose }) => {
  const { profile, signOut, updateProfile } = useAuth();
  const { colorMode } = useTheme();
  const [showPremium, setShowPremium] = useState(false);
  const [activeSection, setActiveSection] = useState<string | null>(null);
  const [settings, setSettings] = useState({
    notifications: {
      matches: true,
      messages: true,
      newProperties: true,
      promotions: false
    },
    privacy: {
      showAge: true,
      showLocation: true,
      allowMessages: true,
      profileVisibility: 'public'
    },
    preferences: {
      theme: 'light',
      language: 'en',
      currency: 'USD',
      distanceUnit: 'miles'
    }
  });

  const isPremium = profile?.package === 'premium';

  const handleSettingChange = (section: string, key: string, value: any) => {
    setSettings(prev => ({
      ...prev,
      [section]: {
        ...prev[section as keyof typeof prev],
        [key]: value
      }
    }));
  };

  const handleSaveSettings = async () => {
    try {
      await updateProfile({
        notification_preferences: settings.notifications,
        privacy_settings: settings.privacy,
        app_preferences: settings.preferences
      });
    } catch (error) {
      console.error('Error saving settings:', error);
    }
  };

  const settingSections = [
    {
      id: 'account',
      title: 'Account',
      icon: User,
      items: [
        { label: 'Edit Profile', action: () => setActiveSection('profile') },
        { label: 'Subscription', action: () => setShowPremium(true), premium: !isPremium },
        { label: 'Verification', action: () => setActiveSection('verification') }
      ]
    },
    {
      id: 'notifications',
      title: 'Notifications',
      icon: Bell,
      items: [
        { 
          label: 'New Matches', 
          type: 'toggle', 
          value: settings.notifications.matches,
          onChange: (value: boolean) => handleSettingChange('notifications', 'matches', value)
        },
        { 
          label: 'Messages', 
          type: 'toggle', 
          value: settings.notifications.messages,
          onChange: (value: boolean) => handleSettingChange('notifications', 'messages', value)
        },
        { 
          label: 'New Properties', 
          type: 'toggle', 
          value: settings.notifications.newProperties,
          onChange: (value: boolean) => handleSettingChange('notifications', 'newProperties', value)
        },
        { 
          label: 'Promotions', 
          type: 'toggle', 
          value: settings.notifications.promotions,
          onChange: (value: boolean) => handleSettingChange('notifications', 'promotions', value)
        }
      ]
    },
    {
      id: 'privacy',
      title: 'Privacy & Safety',
      icon: Shield,
      items: [
        { 
          label: 'Show Age', 
          type: 'toggle', 
          value: settings.privacy.showAge,
          onChange: (value: boolean) => handleSettingChange('privacy', 'showAge', value)
        },
        { 
          label: 'Show Location', 
          type: 'toggle', 
          value: settings.privacy.showLocation,
          onChange: (value: boolean) => handleSettingChange('privacy', 'showLocation', value)
        },
        { 
          label: 'Allow Messages', 
          type: 'toggle', 
          value: settings.privacy.allowMessages,
          onChange: (value: boolean) => handleSettingChange('privacy', 'allowMessages', value)
        },
        { label: 'Blocked Users', action: () => setActiveSection('blocked') },
        { label: 'Report a Problem', action: () => setActiveSection('report') }
      ]
    },
    {
      id: 'preferences',
      title: 'App Preferences',
      icon: Filter,
      items: [
        { 
          label: 'Color Mode', 
          type: 'custom',
          component: () => (
            <div className="flex items-center justify-between py-3">
              <span className="text-gray-700">Color Mode</span>
              <ColorModeToggle size="sm" showLabel={true} />
            </div>
          )
        },
        { 
          label: 'Theme', 
          type: 'select', 
          value: settings.preferences.theme,
          options: [
            { value: 'light', label: 'Light' },
            { value: 'dark', label: 'Dark' },
            { value: 'auto', label: 'Auto' }
          ],
          onChange: (value: string) => handleSettingChange('preferences', 'theme', value)
        },
        { 
          label: 'Language', 
          type: 'select', 
          value: settings.preferences.language,
          options: [
            { value: 'en', label: 'English' },
            { value: 'es', label: 'Español' },
            { value: 'fr', label: 'Français' }
          ],
          onChange: (value: string) => handleSettingChange('preferences', 'language', value)
        },
        { 
          label: 'Distance Unit', 
          type: 'select', 
          value: settings.preferences.distanceUnit,
          options: [
            { value: 'miles', label: 'Miles' },
            { value: 'kilometers', label: 'Kilometers' }
          ],
          onChange: (value: string) => handleSettingChange('preferences', 'distanceUnit', value)
        }
      ]
    }
  ];

  const renderSettingItem = (item: any) => {
    if (item.type === 'toggle') {
      return (
        <div className="flex items-center justify-between py-3">
          <span className="text-gray-700">{item.label}</span>
          <button
            onClick={() => item.onChange(!item.value)}
            className={`relative w-12 h-6 rounded-full transition-colors ${
              item.value ? 'bg-orange-500' : 'bg-gray-300'
            }`}
          >
            <div
              className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${
                item.value ? 'translate-x-7' : 'translate-x-1'
              }`}
            />
          </button>
        </div>
      );
    }

    if (item.type === 'select') {
      return (
        <div className="py-3">
          <label className="block text-gray-700 mb-2">{item.label}</label>
          <select
            value={item.value}
            onChange={(e) => item.onChange(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
          >
            {item.options.map((option: any) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
      );
    }

    if (item.type === 'custom' && item.component) {
      return item.component();
    }

    return (
      <button
        onClick={item.action}
        className="flex items-center justify-between py-3 w-full text-left hover:bg-gray-50 rounded-lg px-2 transition-colors"
      >
        <span className={`${item.premium ? 'text-orange-500 font-medium' : 'text-gray-700'}`}>
          {item.label}
          {item.premium && <span className="ml-2 text-xs bg-orange-100 text-orange-600 px-2 py-1 rounded-full">Premium</span>}
        </span>
        <ChevronRight className="w-4 h-4 text-gray-400" />
      </button>
    );
  };

  return (
    <>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 z-50 flex items-end"
        onClick={onClose}
      >
        <motion.div
          initial={{ y: '100%' }}
          animate={{ y: 0 }}
          exit={{ y: '100%' }}
          transition={{ type: 'spring', damping: 25, stiffness: 200 }}
          className="w-full bg-white rounded-t-3xl max-h-[90vh] overflow-hidden"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-gray-200">
            <h2 className="text-xl font-bold text-gray-800">Settings</h2>
            <button
              onClick={onClose}
              className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center"
            >
              <X className="w-5 h-5 text-gray-600" />
            </button>
          </div>

          <div className="overflow-y-auto max-h-[calc(90vh-140px)]">
            {/* User Info */}
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center space-x-4">
                <div className="w-16 h-16 bg-gradient-to-br from-orange-400 to-red-500 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-xl">
                    {profile?.full_name?.charAt(0) || 'C'}
                  </span>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-800">{profile?.full_name}</h3>
                  <p className="text-gray-600">{profile?.email}</p>
                  <div className="flex items-center space-x-2 mt-1">
                    <span className="text-sm text-gray-500 capitalize">{profile?.role}</span>
                    {isPremium && (
                      <span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs font-semibold">
                        Premium
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Settings Sections */}
            <div className="p-6 space-y-6">
              {settingSections.map((section) => (
                <div key={section.id} className="space-y-3">
                  <div className="flex items-center space-x-3 mb-4">
                    <section.icon className="w-5 h-5 text-orange-500" />
                    <h3 className="text-lg font-semibold text-gray-800">{section.title}</h3>
                  </div>
                  
                  <div className="bg-gray-50 rounded-xl p-4 space-y-2">
                    {section.items.map((item, index) => (
                      <div key={index}>
                        {renderSettingItem(item)}
                      </div>
                    ))}
                  </div>
                </div>
              ))}

              {/* Help & Support */}
              <div className="space-y-3">
                <div className="flex items-center space-x-3 mb-4">
                  <HelpCircle className="w-5 h-5 text-orange-500" />
                  <h3 className="text-lg font-semibold text-gray-800">Help & Support</h3>
                </div>
                
                <div className="bg-gray-50 rounded-xl p-4 space-y-2">
                  <button className="flex items-center justify-between py-3 w-full text-left hover:bg-gray-100 rounded-lg px-2 transition-colors">
                    <span className="text-gray-700">Help Center</span>
                    <ChevronRight className="w-4 h-4 text-gray-400" />
                  </button>
                  <button className="flex items-center justify-between py-3 w-full text-left hover:bg-gray-100 rounded-lg px-2 transition-colors">
                    <span className="text-gray-700">Contact Support</span>
                    <ChevronRight className="w-4 h-4 text-gray-400" />
                  </button>
                  <button className="flex items-center justify-between py-3 w-full text-left hover:bg-gray-100 rounded-lg px-2 transition-colors">
                    <span className="text-gray-700">Terms of Service</span>
                    <ChevronRight className="w-4 h-4 text-gray-400" />
                  </button>
                  <button className="flex items-center justify-between py-3 w-full text-left hover:bg-gray-100 rounded-lg px-2 transition-colors">
                    <span className="text-gray-700">Privacy Policy</span>
                    <ChevronRight className="w-4 h-4 text-gray-400" />
                  </button>
                </div>
              </div>

              {/* Logout Section */}
              <div className="pt-4 border-t border-gray-200">
                <button
                  onClick={signOut}
                  className="flex items-center space-x-3 w-full py-3 px-4 text-red-600 hover:bg-red-50 rounded-xl transition-colors"
                >
                  <LogOut className="w-5 h-5" />
                  <span className="font-medium">Sign Out</span>
                </button>
              </div>
            </div>
          </div>

          {/* Save Button */}
          <div className="p-6 border-t border-gray-200 bg-gray-50">
            <button
              onClick={handleSaveSettings}
              className="w-full bg-gradient-to-r from-orange-500 to-red-500 text-white py-3 rounded-xl font-semibold hover:shadow-lg transition-all"
            >
              Save Settings
            </button>
          </div>
        </motion.div>
      </motion.div>

      {/* Premium Modal */}
      {showPremium && (
        <PremiumModal
          userType="client"
          onClose={() => setShowPremium(false)}
        />
      )}
    </>
  );
};

export default ClientSettings;