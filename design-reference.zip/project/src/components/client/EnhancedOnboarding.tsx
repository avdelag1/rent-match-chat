import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ArrowRight, 
  ArrowLeft, 
  User, 
  MapPin, 
  DollarSign, 
  Home, 
  Heart,
  Camera,
  Check,
  Star
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import PhotoUpload from '../common/PhotoUpload';
import toast from 'react-hot-toast';

interface EnhancedOnboardingProps {
  onComplete: () => void;
}

const EnhancedOnboarding: React.FC<EnhancedOnboardingProps> = ({ onComplete }) => {
  const { profile, updateProfile } = useAuth();
  const [currentStep, setCurrentStep] = useState(1);
  const [loading, setLoading] = useState(false);
  
  const [onboardingData, setOnboardingData] = useState({
    // Personal Info
    age: profile?.age?.toString() || '',
    occupation: profile?.occupation || '',
    bio: profile?.bio || '',
    location: profile?.location || '',
    
    // Photos
    images: profile?.images || [],
    
    // Preferences
    budget_min: profile?.budget_min?.toString() || '',
    budget_max: profile?.budget_max?.toString() || '',
    preferred_property_types: profile?.preferred_property_types || [],
    preferred_locations: profile?.preferred_locations || [],
    min_bedrooms: profile?.min_bedrooms?.toString() || '1',
    max_bedrooms: profile?.max_bedrooms?.toString() || '3',
    furnished_preference: profile?.furnished_preference || 'any',
    pet_preference: profile?.pet_preference || false,
    
    // Lifestyle
    lifestyle_tags: profile?.lifestyle_tags || [],
    interests: profile?.interests || [],
    smoking: profile?.smoking || false,
    party_friendly: profile?.party_friendly || false
  });

  const totalSteps = 4;

  const propertyTypes = [
    'apartment', 'house', 'studio', 'penthouse', 'room', 'loft'
  ];

  const lifestyleTags = [
    'professional', 'student', 'creative', 'social', 'quiet', 
    'fitness_enthusiast', 'foodie', 'traveler', 'homebody', 'early_riser'
  ];

  const interests = [
    'music', 'sports', 'reading', 'cooking', 'gaming', 'art', 
    'technology', 'fitness', 'travel', 'photography', 'movies', 'nature'
  ];

  const handleInputChange = (field: string, value: any) => {
    setOnboardingData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const toggleArrayItem = (array: string[], item: string): string[] => {
    return array.includes(item) 
      ? array.filter(i => i !== item)
      : [...array, item];
  };

  const nextStep = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const handleComplete = async () => {
    setLoading(true);
    
    try {
      console.log('Onboarding: Completing with data:', onboardingData);
      await updateProfile({
        ...onboardingData,
        age: onboardingData.age ? parseInt(onboardingData.age) : undefined,
        budget_min: onboardingData.budget_min ? parseFloat(onboardingData.budget_min) : undefined,
        budget_max: onboardingData.budget_max ? parseFloat(onboardingData.budget_max) : undefined,
        min_bedrooms: onboardingData.min_bedrooms ? parseInt(onboardingData.min_bedrooms) : undefined,
        max_bedrooms: onboardingData.max_bedrooms ? parseInt(onboardingData.max_bedrooms) : undefined,
        onboarding_completed: true
      });
      
      console.log('Onboarding: Profile updated successfully');
      toast.success('Profile setup complete!');
      
      // Small delay to ensure state updates
      await new Promise(resolve => setTimeout(resolve, 500));
      onComplete();
    } catch (error) {
      console.error('Error completing onboarding:', error);
      toast.error('Failed to save profile');
    } finally {
      setLoading(false);
    }
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <User className="w-16 h-16 mx-auto mb-4 text-orange-500" />
              <h2 className="text-2xl font-bold text-gray-800 mb-2">Tell us about yourself</h2>
              <p className="text-gray-600">Help us create your perfect profile</p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Age</label>
                <input
                  type="number"
                  value={onboardingData.age}
                  onChange={(e) => handleInputChange('age', e.target.value)}
                  min="18"
                  max="100"
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  placeholder="Enter your age"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Occupation</label>
                <input
                  type="text"
                  value={onboardingData.occupation}
                  onChange={(e) => handleInputChange('occupation', e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  placeholder="What do you do for work?"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Location</label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="text"
                    value={onboardingData.location}
                    onChange={(e) => handleInputChange('location', e.target.value)}
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                    placeholder="City, State"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Bio</label>
                <textarea
                  value={onboardingData.bio}
                  onChange={(e) => handleInputChange('bio', e.target.value)}
                  rows={4}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent resize-none"
                  placeholder="Tell us about yourself, your lifestyle, and what you're looking for..."
                />
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <PhotoUpload
              photos={onboardingData.images}
              onPhotosChange={(photos) => handleInputChange('images', photos)}
              maxPhotos={10}
              maxFileSize={5}
              title="Add Your Photos"
              description="Upload photos that represent you and your lifestyle"
              required={true}
            />
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <DollarSign className="w-16 h-16 mx-auto mb-4 text-orange-500" />
              <h2 className="text-2xl font-bold text-gray-800 mb-2">Budget & Preferences</h2>
              <p className="text-gray-600">What are you looking for?</p>
            </div>

            <div className="space-y-6">
              {/* Budget Range */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">Budget Range</label>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs text-gray-600 mb-1">Minimum</label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                      <input
                        type="number"
                        value={onboardingData.budget_min}
                        onChange={(e) => handleInputChange('budget_min', e.target.value)}
                        className="w-full pl-9 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                        placeholder="1000"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs text-gray-600 mb-1">Maximum</label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                      <input
                        type="number"
                        value={onboardingData.budget_max}
                        onChange={(e) => handleInputChange('budget_max', e.target.value)}
                        className="w-full pl-9 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                        placeholder="3000"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Property Types */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">Property Types</label>
                <div className="grid grid-cols-2 gap-2">
                  {propertyTypes.map((type) => (
                    <button
                      key={type}
                      type="button"
                      onClick={() => handleInputChange('preferred_property_types', 
                        toggleArrayItem(onboardingData.preferred_property_types, type)
                      )}
                      className={`p-3 rounded-xl border-2 transition-all capitalize ${
                        onboardingData.preferred_property_types.includes(type)
                          ? 'border-orange-500 bg-orange-50 text-orange-700'
                          : 'border-gray-200 text-gray-700 hover:border-gray-300'
                      }`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>

              {/* Bedrooms */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Min Bedrooms</label>
                  <select
                    value={onboardingData.min_bedrooms}
                    onChange={(e) => handleInputChange('min_bedrooms', e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  >
                    <option value="0">Studio</option>
                    <option value="1">1+</option>
                    <option value="2">2+</option>
                    <option value="3">3+</option>
                    <option value="4">4+</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Max Bedrooms</label>
                  <select
                    value={onboardingData.max_bedrooms}
                    onChange={(e) => handleInputChange('max_bedrooms', e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  >
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5+</option>
                  </select>
                </div>
              </div>

              {/* Additional Preferences */}
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Furnished Preference</label>
                  <select
                    value={onboardingData.furnished_preference}
                    onChange={(e) => handleInputChange('furnished_preference', e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  >
                    <option value="any">Any</option>
                    <option value="furnished">Furnished</option>
                    <option value="unfurnished">Unfurnished</option>
                  </select>
                </div>

                <label className="flex items-center space-x-3">
                  <input
                    type="checkbox"
                    checked={onboardingData.pet_preference}
                    onChange={(e) => handleInputChange('pet_preference', e.target.checked)}
                    className="w-5 h-5 text-orange-500 border-gray-300 rounded focus:ring-orange-500"
                  />
                  <span className="text-gray-700">Pet-friendly properties preferred</span>
                </label>
              </div>
            </div>
          </div>
        );

      case 4:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <Heart className="w-16 h-16 mx-auto mb-4 text-orange-500" />
              <h2 className="text-2xl font-bold text-gray-800 mb-2">Lifestyle & Interests</h2>
              <p className="text-gray-600">Help us find compatible properties and owners</p>
            </div>

            <div className="space-y-6">
              {/* Lifestyle Tags */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">Lifestyle</label>
                <div className="grid grid-cols-2 gap-2">
                  {lifestyleTags.map((tag) => (
                    <button
                      key={tag}
                      type="button"
                      onClick={() => handleInputChange('lifestyle_tags', 
                        toggleArrayItem(onboardingData.lifestyle_tags, tag)
                      )}
                      className={`p-3 rounded-xl border-2 transition-all text-sm capitalize ${
                        onboardingData.lifestyle_tags.includes(tag)
                          ? 'border-purple-500 bg-purple-50 text-purple-700'
                          : 'border-gray-200 text-gray-700 hover:border-gray-300'
                      }`}
                    >
                      {tag.replace('_', ' ')}
                    </button>
                  ))}
                </div>
              </div>

              {/* Interests */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">Interests</label>
                <div className="grid grid-cols-3 gap-2">
                  {interests.map((interest) => (
                    <button
                      key={interest}
                      type="button"
                      onClick={() => handleInputChange('interests', 
                        toggleArrayItem(onboardingData.interests, interest)
                      )}
                      className={`p-2 rounded-lg border-2 transition-all text-sm capitalize ${
                        onboardingData.interests.includes(interest)
                          ? 'border-green-500 bg-green-50 text-green-700'
                          : 'border-gray-200 text-gray-700 hover:border-gray-300'
                      }`}
                    >
                      {interest}
                    </button>
                  ))}
                </div>
              </div>

              {/* Lifestyle Preferences */}
              <div className="space-y-4">
                <h4 className="font-semibold text-gray-800">Lifestyle Preferences</h4>
                
                <div className="grid grid-cols-2 gap-4">
                  <label className="flex items-center space-x-3">
                    <input
                      type="checkbox"
                      checked={onboardingData.smoking}
                      onChange={(e) => handleInputChange('smoking', e.target.checked)}
                      className="w-5 h-5 text-orange-500 border-gray-300 rounded focus:ring-orange-500"
                    />
                    <span className="text-gray-700">Smoking friendly</span>
                  </label>

                  <label className="flex items-center space-x-3">
                    <input
                      type="checkbox"
                      checked={onboardingData.party_friendly}
                      onChange={(e) => handleInputChange('party_friendly', e.target.checked)}
                      className="w-5 h-5 text-orange-500 border-gray-300 rounded focus:ring-orange-500"
                    />
                    <span className="text-gray-700">Party friendly</span>
                  </label>
                </div>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  const canProceed = () => {
    switch (currentStep) {
      case 1:
        return onboardingData.age && onboardingData.bio && onboardingData.location;
      case 2:
        return onboardingData.images.length >= 1;
      case 3:
        return onboardingData.budget_min && onboardingData.budget_max && 
               onboardingData.preferred_property_types.length > 0;
      case 4:
        return onboardingData.lifestyle_tags.length > 0;
      default:
        return false;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-500 via-red-500 to-orange-500 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-2xl bg-white rounded-3xl shadow-2xl overflow-hidden"
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-orange-500 to-red-500 p-6 text-white">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold">Complete Your Profile</h1>
            <div className="text-sm bg-white/20 px-3 py-1 rounded-full">
              Step {currentStep} of {totalSteps}
            </div>
          </div>
          
          {/* Progress Bar */}
          <div className="w-full bg-white/20 rounded-full h-2">
            <motion.div
              className="bg-white h-2 rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${(currentStep / totalSteps) * 100}%` }}
              transition={{ duration: 0.5 }}
            />
          </div>
        </div>

        {/* Content */}
        <div className="p-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentStep}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
            >
              {renderStep()}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-gray-200 bg-gray-50">
          <div className="flex justify-between">
            <button
              onClick={prevStep}
              disabled={currentStep === 1}
              className="flex items-center space-x-2 px-6 py-3 border border-gray-300 rounded-xl text-gray-700 font-semibold hover:bg-gray-100 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Previous</span>
            </button>

            {currentStep < totalSteps ? (
              <button
                onClick={nextStep}
                disabled={!canProceed()}
                className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-xl font-semibold hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <span>Next</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            ) : (
              <button
                onClick={handleComplete}
                disabled={!canProceed() || loading}
                className="flex items-center space-x-2 px-8 py-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-xl font-semibold hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Saving...</span>
                  </>
                ) : (
                  <>
                    <Check className="w-4 h-4" />
                    <span>Complete Setup</span>
                  </>
                )}
              </button>
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default EnhancedOnboarding;