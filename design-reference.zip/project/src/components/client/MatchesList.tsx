import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { X, MessageCircle, Heart, Clock } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { supabase, Match } from '../../lib/supabase';
import ChatModal from '../messaging/ChatModal';
import PremiumModal from '../subscription/PremiumModal';

interface MatchesListProps {
  onClose: () => void;
}

const MatchesList: React.FC<MatchesListProps> = ({ onClose }) => {
  const { profile } = useAuth();
  const [matches, setMatches] = useState<Match[]>([]);
  const [selectedMatch, setSelectedMatch] = useState<Match | null>(null);
  const [showPremium, setShowPremium] = useState(false);
  const [loading, setLoading] = useState(true);

  const isPremium = profile?.package === 'premium' || profile?.package === 'unlimited';

  useEffect(() => {
    fetchMatches();
  }, [profile]);

  const fetchMatches = async () => {
    if (!profile) return;

    try {
      const { data, error } = await supabase
        .from('matches')
        .select(`
          *,
          owner:profiles!matches_owner_id_fkey(*),
          property:properties(*)
        `)
        .eq('client_id', profile.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setMatches(data || []);
    } catch (error) {
      console.error('Error fetching matches:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleChatClick = (match: Match) => {
    if (!isPremium) {
      setShowPremium(true);
      return;
    }
    setSelectedMatch(match);
  };

  if (loading) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center"
      >
        <div className="text-white text-center">
          <div className="w-16 h-16 border-4 border-white border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-xl">Loading matches...</p>
        </div>
      </motion.div>
    );
  }

  return (
    <>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 z-50 flex items-end"
        onClick={onClose}
      >
        <motion.div
          initial={{ y: '100%' }}
          animate={{ y: 0 }}
          exit={{ y: '100%' }}
          transition={{ type: 'spring', damping: 25, stiffness: 200 }}
          className="w-full bg-white rounded-t-3xl max-h-[90vh] overflow-hidden"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-gray-200">
            <div className="flex items-center space-x-3">
              <Heart className="w-6 h-6 text-red-500" />
              <h2 className="text-xl font-bold text-gray-800">Your Matches</h2>
            </div>
            <button
              onClick={onClose}
              className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center"
            >
              <X className="w-5 h-5 text-gray-600" />
            </button>
          </div>

          <div className="overflow-y-auto max-h-[calc(90vh-140px)]">
            {matches.length === 0 ? (
              <div className="text-center py-20">
                <Heart className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                <h3 className="text-xl font-semibold text-gray-600 mb-2">No matches yet</h3>
                <p className="text-gray-500">Keep swiping to find your perfect property!</p>
              </div>
            ) : (
              <div className="p-6 space-y-4">
                {matches.map((match) => (
                  <motion.div
                    key={match.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-white border border-gray-200 rounded-2xl p-4 shadow-sm hover:shadow-md transition-all"
                  >
                    <div className="flex items-center space-x-4">
                      {/* Property Image */}
                      <div className="w-20 h-20 rounded-xl overflow-hidden flex-shrink-0">
                        <img
                          src={match.listing?.images?.[0] || 'https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg'}
                          alt={match.property?.title}
                          className="w-full h-full object-cover"
                        />
                      </div>

                      {/* Match Info */}
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-gray-800 truncate">
                          {match.listing?.title}
                        </h3>
                        <p className="text-sm text-gray-600 mb-1">
                          Owner: {match.owner?.full_name}
                        </p>
                        <div className="flex items-center text-xs text-gray-500">
                          <Clock className="w-3 h-3 mr-1" />
                          <span>
                            Matched {new Date(match.created_at).toLocaleDateString()}
                          </span>
                        </div>
                      </div>

                      {/* Chat Button */}
                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => handleChatClick(match)}
                        className={`w-12 h-12 rounded-full flex items-center justify-center transition-all ${
                          isPremium
                            ? 'bg-gradient-to-r from-orange-500 to-red-500 text-white shadow-lg'
                            : 'bg-gray-100 text-gray-400'
                        }`}
                      >
                        <MessageCircle className="w-5 h-5" />
                      </motion.button>
                    </div>

                    {!isPremium && (
                      <div className="mt-3 p-3 bg-yellow-50 border border-yellow-200 rounded-xl">
                        <p className="text-sm text-yellow-800 text-center">
                          Upgrade to Premium to start chatting
                        </p>
                      </div>
                    )}
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        </motion.div>
      </motion.div>

      {/* Chat Modal */}
      {selectedMatch && (
        <ChatModal
          match={selectedMatch}
          onClose={() => setSelectedMatch(null)}
        />
      )}

      {/* Premium Modal */}
      {showPremium && (
        <PremiumModal
          userType="client"
          onClose={() => setShowPremium(false)}
        />
      )}
    </>
  );
};

export default MatchesList;