import React from 'react';
import { motion } from 'framer-motion';
import { X, Crown, Zap, MessageCircle, Eye, Filter, Star } from 'lucide-react';

interface PremiumModalProps {
  userType: 'client' | 'owner';
  onClose: () => void;
}

const PremiumModal: React.FC<PremiumModalProps> = ({ userType, onClose }) => {
  const clientFeatures = [
    { icon: MessageCircle, title: 'Unlimited Messaging', description: 'Chat with all your matches' },
    { icon: Zap, title: 'Unlimited Swipes', description: 'No daily swipe limits' },
    { icon: Filter, title: 'Advanced Filters', description: 'Find exactly what you want' },
    { icon: Eye, title: 'See Who Liked You', description: 'View your admirers' },
    { icon: Star, title: 'Super Likes', description: 'Stand out to property owners' }
  ];

  const ownerFeatures = [
    { icon: Star, title: 'Featured Listings', description: 'Boost your property visibility' },
    { icon: Eye, title: 'Advanced Analytics', description: 'Track views and engagement' },
    { icon: MessageCircle, title: 'Priority Support', description: 'Get help when you need it' },
    { icon: Zap, title: 'Unlimited Properties', description: 'List as many as you want' },
    { icon: Filter, title: 'Client Insights', description: 'See detailed client profiles' }
  ];

  const features = userType === 'client' ? clientFeatures : ownerFeatures;

  const subscriptionLinks = {
    client: {
      premium: 'https://www.paypal.com/ncp/payment/QSRXCJYYQ2UGY',
      premiumPlus: 'https://www.paypal.com/ncp/payment/HUESWJ68BRUSY',
      unlimited: 'https://www.paypal.com/ncp/payment/7E6R38L33LYUJ'
    },
    owner: {
      premium: 'https://www.paypal.com/ncp/payment/OWNERLINK1',
      premiumPlus: 'https://www.paypal.com/ncp/payment/OWNERLINK2',
      unlimited: 'https://www.paypal.com/ncp/payment/OWNERLINK3'
    }
  };

  const handleSubscribe = (plan: string) => {
    const links = subscriptionLinks[userType];
    let url = '';
    
    switch (plan) {
      case 'premium':
        url = links.premium;
        break;
      case 'premiumPlus':
        url = links.premiumPlus;
        break;
      case 'unlimited':
        url = links.unlimited;
        break;
    }

    if (url) {
      window.open(url, '_blank');
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="w-full max-w-md bg-white rounded-3xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-yellow-400 to-orange-500 p-6 text-center relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 w-8 h-8 bg-white/20 rounded-full flex items-center justify-center"
          >
            <X className="w-5 h-5 text-white" />
          </button>
          
          <Crown className="w-16 h-16 mx-auto mb-4 text-white" />
          <h2 className="text-2xl font-bold text-white mb-2">
            Upgrade to Premium
          </h2>
          <p className="text-white/90">
            Unlock all features and find your perfect {userType === 'client' ? 'property' : 'tenant'} faster
          </p>
        </div>

        {/* Features */}
        <div className="p-6">
          <div className="space-y-4 mb-6">
            {features.map((feature, index) => (
              <div key={index} className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center">
                  <feature.icon className="w-5 h-5 text-orange-500" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-800">{feature.title}</h3>
                  <p className="text-sm text-gray-600">{feature.description}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Pricing Plans */}
          <div className="space-y-3">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => handleSubscribe('premium')}
              className="w-full p-4 border-2 border-orange-200 rounded-xl hover:border-orange-300 transition-all"
            >
              <div className="flex items-center justify-between">
                <div className="text-left">
                  <h3 className="font-semibold text-gray-800">Premium</h3>
                  <p className="text-sm text-gray-600">Essential features</p>
                </div>
                <div className="text-right">
                  <div className="text-xl font-bold text-orange-500">$9.99</div>
                  <div className="text-sm text-gray-600">per month</div>
                </div>
              </div>
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => handleSubscribe('premiumPlus')}
              className="w-full p-4 bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-xl shadow-lg"
            >
              <div className="flex items-center justify-between">
                <div className="text-left">
                  <div className="flex items-center space-x-2">
                    <h3 className="font-semibold">Premium+</h3>
                    <span className="bg-yellow-400 text-black text-xs px-2 py-1 rounded-full font-semibold">
                      POPULAR
                    </span>
                  </div>
                  <p className="text-sm text-white/90">All features + priority</p>
                </div>
                <div className="text-right">
                  <div className="text-xl font-bold">$19.99</div>
                  <div className="text-sm text-white/90">per month</div>
                </div>
              </div>
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => handleSubscribe('unlimited')}
              className="w-full p-4 border-2 border-purple-200 rounded-xl hover:border-purple-300 transition-all"
            >
              <div className="flex items-center justify-between">
                <div className="text-left">
                  <h3 className="font-semibold text-gray-800">Unlimited</h3>
                  <p className="text-sm text-gray-600">Everything + VIP status</p>
                </div>
                <div className="text-right">
                  <div className="text-xl font-bold text-purple-500">$39.99</div>
                  <div className="text-sm text-gray-600">per month</div>
                </div>
              </div>
            </motion.button>
          </div>

          <p className="text-xs text-gray-500 text-center mt-4">
            Cancel anytime. Secure payment via PayPal.
          </p>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default PremiumModal;