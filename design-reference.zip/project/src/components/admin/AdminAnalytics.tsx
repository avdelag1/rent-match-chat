import React from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, Users, Home, DollarSign, MessageCircle, Heart } from 'lucide-react';

const AdminAnalytics: React.FC = () => {
  const analyticsData = [
    {
      title: 'Platform Revenue',
      value: '$45,230',
      change: '+12.5%',
      icon: DollarSign,
      color: 'green'
    },
    {
      title: 'Total Users',
      value: '2,847',
      change: '+8.2%',
      icon: Users,
      color: 'blue'
    },
    {
      title: 'Active Properties',
      value: '1,234',
      change: '+15.3%',
      icon: Home,
      color: 'orange'
    },
    {
      title: 'Total Matches',
      value: '5,678',
      change: '+23.1%',
      icon: Heart,
      color: 'red'
    },
    {
      title: 'Messages Sent',
      value: '12,456',
      change: '+18.7%',
      icon: MessageCircle,
      color: 'purple'
    },
    {
      title: 'Conversion Rate',
      value: '3.2%',
      change: '+0.8%',
      icon: TrendingUp,
      color: 'indigo'
    }
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      green: 'bg-green-50 text-green-600 border-green-200',
      blue: 'bg-blue-50 text-blue-600 border-blue-200',
      orange: 'bg-orange-50 text-orange-600 border-orange-200',
      red: 'bg-red-50 text-red-600 border-red-200',
      purple: 'bg-purple-50 text-purple-600 border-purple-200',
      indigo: 'bg-indigo-50 text-indigo-600 border-indigo-200'
    };
    return colors[color as keyof typeof colors] || colors.blue;
  };

  return (
    <div className="p-6">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Platform Analytics</h2>
        <p className="text-gray-600">Overview of Tinderent platform performance</p>
      </div>

      {/* Analytics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {analyticsData.map((item, index) => (
          <motion.div
            key={item.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className={`p-6 rounded-2xl border-2 ${getColorClasses(item.color)}`}
          >
            <div className="flex items-center justify-between mb-4">
              <item.icon className="w-8 h-8" />
              <span className="text-sm font-medium text-green-600 bg-green-100 px-2 py-1 rounded-full">
                {item.change}
              </span>
            </div>
            <div className="text-3xl font-bold mb-1">{item.value}</div>
            <div className="text-sm opacity-80">{item.title}</div>
          </motion.div>
        ))}
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Revenue Chart */}
        <div className="bg-white rounded-2xl border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Revenue Trends</h3>
          <div className="h-64 bg-gray-50 rounded-xl flex items-center justify-center">
            <div className="text-center text-gray-500">
              <TrendingUp className="w-12 h-12 mx-auto mb-4 text-gray-300" />
              <p>Revenue chart visualization</p>
              <p className="text-sm">Coming soon</p>
            </div>
          </div>
        </div>

        {/* User Growth Chart */}
        <div className="bg-white rounded-2xl border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">User Growth</h3>
          <div className="h-64 bg-gray-50 rounded-xl flex items-center justify-center">
            <div className="text-center text-gray-500">
              <Users className="w-12 h-12 mx-auto mb-4 text-gray-300" />
              <p>User growth visualization</p>
              <p className="text-sm">Coming soon</p>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="mt-6 bg-white rounded-2xl border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Recent Platform Activity</h3>
        
        <div className="space-y-4">
          {[
            { action: 'New user registration: Sarah Johnson (Client)', time: '5 minutes ago', type: 'user' },
            { action: 'Property listed: "Modern Downtown Loft"', time: '15 minutes ago', type: 'property' },
            { action: 'Premium subscription activated: John Doe', time: '1 hour ago', type: 'subscription' },
            { action: 'New match created between users', time: '2 hours ago', type: 'match' },
            { action: 'Property reported for review', time: '3 hours ago', type: 'report' }
          ].map((activity, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className="flex items-center space-x-3 p-4 hover:bg-gray-50 rounded-xl transition-colors"
            >
              <div className={`w-3 h-3 rounded-full ${
                activity.type === 'user' ? 'bg-blue-500' :
                activity.type === 'property' ? 'bg-orange-500' :
                activity.type === 'subscription' ? 'bg-green-500' :
                activity.type === 'match' ? 'bg-red-500' :
                'bg-yellow-500'
              }`} />
              <div className="flex-1">
                <p className="text-gray-800 text-sm">{activity.action}</p>
                <p className="text-gray-500 text-xs">{activity.time}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AdminAnalytics;