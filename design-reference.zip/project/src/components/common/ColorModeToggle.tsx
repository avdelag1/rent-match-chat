import React from 'react';
import { motion } from 'framer-motion';
import { Sun, Moon, Palette } from 'lucide-react';
import { useTheme, ColorMode } from '../../contexts/ThemeContext';

interface ColorModeToggleProps {
  className?: string;
  showLabel?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

const ColorModeToggle: React.FC<ColorModeToggleProps> = ({ 
  className = '', 
  showLabel = true,
  size = 'md' 
}) => {
  const { colorMode, toggleColorMode } = useTheme();

  const getModeIcon = (mode: ColorMode) => {
    const iconSize = size === 'sm' ? 'w-4 h-4' : size === 'lg' ? 'w-6 h-6' : 'w-5 h-5';
    
    switch (mode) {
      case 'normal':
        return <Sun className={`${iconSize} text-yellow-500`} />;
      case 'dark':
        return <Moon className={`${iconSize} text-blue-400`} />;
      case 'amber':
        return <Palette className={`${iconSize} text-amber-500`} />;
    }
  };

  const getModeLabel = (mode: ColorMode) => {
    switch (mode) {
      case 'normal':
        return 'Normal';
      case 'dark':
        return 'Dark';
      case 'amber':
        return 'Amber';
    }
  };

  const getButtonSize = () => {
    switch (size) {
      case 'sm':
        return 'w-8 h-8';
      case 'lg':
        return 'w-12 h-12';
      default:
        return 'w-10 h-10';
    }
  };

  return (
    <div className={`flex items-center space-x-2 ${className}`}>
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={toggleColorMode}
        className={`${getButtonSize()} bg-white/20 hover:bg-white/30 backdrop-blur-sm rounded-full flex items-center justify-center transition-all duration-200 border border-white/20`}
        title={`Switch to ${getModeLabel(colorMode)} mode`}
      >
        <motion.div
          key={colorMode}
          initial={{ rotate: -180, opacity: 0 }}
          animate={{ rotate: 0, opacity: 1 }}
          transition={{ duration: 0.3 }}
        >
          {getModeIcon(colorMode)}
        </motion.div>
      </motion.button>
      
      {showLabel && (
        <span className="text-white/90 text-sm font-medium">
          {getModeLabel(colorMode)}
        </span>
      )}
    </div>
  );
};

export default ColorModeToggle;