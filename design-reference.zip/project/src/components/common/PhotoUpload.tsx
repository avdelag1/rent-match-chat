import React, { useState, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Upload, X, Camera, Image as ImageIcon, AlertCircle, Check, RotateCcw, Crop, Plus } from 'lucide-react';
import toast from 'react-hot-toast';

interface PhotoUploadProps {
  photos: string[];
  onPhotosChange: (photos: string[]) => void;
  maxPhotos?: number;
  maxFileSize?: number; // in MB
  className?: string;
  required?: boolean;
  title?: string;
  description?: string;
}

interface UploadProgress {
  file: File;
  progress: number;
  status: 'uploading' | 'completed' | 'error';
  url?: string;
  id: string;
}

const PhotoUpload: React.FC<PhotoUploadProps> = ({ 
  photos, 
  onPhotosChange, 
  maxPhotos = 10,
  maxFileSize = 5, // 5MB default
  className = '',
  required = false,
  title = "Upload Photos",
  description = "Add up to 10 high-quality photos"
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<UploadProgress[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
  const maxFileSizeBytes = maxFileSize * 1024 * 1024;

  // File validation
  const validateFile = (file: File): string | null => {
    if (!allowedTypes.includes(file.type)) {
      return `${file.name}: Only JPEG, PNG, and WebP images are allowed`;
    }

    if (file.size > maxFileSizeBytes) {
      return `${file.name}: File size must be less than ${maxFileSize}MB`;
    }

    return null;
  };

  // Validate image dimensions
  const validateImageDimensions = (file: File): Promise<{ width: number; height: number; valid: boolean; error?: string }> => {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        const { width, height } = img;
        
        // Minimum dimensions check
        if (width < 400 || height < 400) {
          resolve({ 
            width, 
            height, 
            valid: false, 
            error: 'Image must be at least 400x400 pixels' 
          });
        } else {
          resolve({ width, height, valid: true });
        }
      };
      img.onerror = () => {
        resolve({ 
          width: 0, 
          height: 0, 
          valid: false, 
          error: 'Invalid image file' 
        });
      };
      img.src = URL.createObjectURL(file);
    });
  };

  // Compress image if needed
  const compressImage = (file: File, maxWidth = 1920, quality = 0.85): Promise<File> => {
    return new Promise((resolve) => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d')!;
      const img = new Image();

      img.onload = () => {
        let { width, height } = img;
        
        // Calculate new dimensions maintaining aspect ratio
        if (width > maxWidth) {
          height = (height * maxWidth) / width;
          width = maxWidth;
        }

        canvas.width = width;
        canvas.height = height;

        // Draw and compress
        ctx.drawImage(img, 0, 0, width, height);
        
        canvas.toBlob(
          (blob) => {
            if (blob) {
              const compressedFile = new File([blob], file.name, {
                type: file.type,
                lastModified: Date.now()
              });
              resolve(compressedFile);
            } else {
              resolve(file);
            }
          },
          file.type,
          quality
        );
      };

      img.src = URL.createObjectURL(file);
    });
  };

  // Simulate photo upload with progress
  const uploadPhoto = async (file: File, progressId: string): Promise<string> => {
    return new Promise((resolve, reject) => {
      let progress = 0;
      const interval = setInterval(() => {
        progress += Math.random() * 25 + 5; // Random progress between 5-30%
        
        setUploadProgress(prev => 
          prev.map(item => 
            item.id === progressId 
              ? { ...item, progress: Math.min(progress, 100) }
              : item
          )
        );

        if (progress >= 100) {
          clearInterval(interval);
          
          // Create blob URL for demo
          const url = URL.createObjectURL(file);
          
          setUploadProgress(prev => 
            prev.map(item => 
              item.id === progressId 
                ? { ...item, progress: 100, status: 'completed', url }
                : item
            )
          );
          
          resolve(url);
        }
      }, 150 + Math.random() * 200); // Random interval for realistic feel
    });
  };

  const handleFileSelect = useCallback(async (files: FileList) => {
    const fileArray = Array.from(files);
    const remainingSlots = maxPhotos - photos.length;
    
    if (fileArray.length > remainingSlots) {
      toast.error(`You can only upload ${remainingSlots} more photo${remainingSlots !== 1 ? 's' : ''}`);
      return;
    }

    setIsUploading(true);

    // Validate and process files
    const validFiles: File[] = [];
    const errors: string[] = [];

    for (const file of fileArray) {
      const validationError = validateFile(file);
      if (validationError) {
        errors.push(validationError);
        continue;
      }

      // Check image dimensions
      const dimensionCheck = await validateImageDimensions(file);
      if (!dimensionCheck.valid) {
        errors.push(`${file.name}: ${dimensionCheck.error}`);
        continue;
      }

      // Compress if needed
      const compressedFile = await compressImage(file);
      validFiles.push(compressedFile);
    }

    // Show validation errors
    if (errors.length > 0) {
      errors.forEach(error => toast.error(error));
    }

    if (validFiles.length === 0) {
      setIsUploading(false);
      return;
    }

    // Initialize upload progress
    const initialProgress = validFiles.map(file => ({
      file,
      progress: 0,
      status: 'uploading' as const,
      id: `${Date.now()}-${Math.random()}`
    }));
    setUploadProgress(initialProgress);

    // Upload files with progress tracking
    try {
      const uploadPromises = initialProgress.map(async (item) => {
        try {
          const url = await uploadPhoto(item.file, item.id);
          return url;
        } catch (error) {
          setUploadProgress(prev => 
            prev.map(p => 
              p.id === item.id 
                ? { ...p, status: 'error' }
                : p
            )
          );
          throw error;
        }
      });

      const uploadedUrls = await Promise.all(uploadPromises);
      onPhotosChange([...photos, ...uploadedUrls]);
      
      toast.success(`${uploadedUrls.length} photo${uploadedUrls.length !== 1 ? 's' : ''} uploaded successfully!`);
    } catch (error) {
      toast.error('Some photos failed to upload');
    } finally {
      setIsUploading(false);
      // Clear upload progress after delay
      setTimeout(() => setUploadProgress([]), 3000);
    }
  }, [photos, onPhotosChange, maxPhotos, maxFileSize]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      handleFileSelect(files);
    }
  }, [handleFileSelect]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const removePhoto = (index: number) => {
    const newPhotos = photos.filter((_, i) => i !== index);
    onPhotosChange(newPhotos);
    toast.success('Photo removed');
  };

  const reorderPhotos = (fromIndex: number, toIndex: number) => {
    const newPhotos = [...photos];
    const [removed] = newPhotos.splice(fromIndex, 1);
    newPhotos.splice(toIndex, 0, removed);
    onPhotosChange(newPhotos);
  };

  const canUploadMore = photos.length < maxPhotos && !isUploading;

  return (
    <div className={`space-y-6 ${className}`}>
      {/* Header */}
      <div className="text-center">
        <h3 className="text-2xl font-bold text-gray-800 mb-2">{title}</h3>
        <p className="text-gray-600">{description}</p>
        {required && (
          <p className="text-sm text-red-600 mt-1">* At least one photo is required</p>
        )}
      </div>

      {/* Upload Area */}
      <div
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        className={`border-2 border-dashed rounded-3xl p-8 text-center transition-all duration-300 ${
          isDragging
            ? 'border-orange-500 bg-orange-50 scale-105'
            : canUploadMore
            ? 'border-gray-300 hover:border-orange-400 hover:bg-orange-50 cursor-pointer'
            : 'border-gray-200 bg-gray-50 cursor-not-allowed opacity-60'
        }`}
        onClick={() => canUploadMore && fileInputRef.current?.click()}
      >
        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept={allowedTypes.join(',')}
          onChange={(e) => e.target.files && handleFileSelect(e.target.files)}
          className="hidden"
          disabled={!canUploadMore}
        />

        <div className="space-y-4">
          <motion.div 
            className="flex justify-center"
            animate={isDragging ? { scale: 1.1 } : { scale: 1 }}
          >
            {photos.length >= maxPhotos ? (
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center">
                <Check className="w-10 h-10 text-green-500" />
              </div>
            ) : isUploading ? (
              <div className="w-20 h-20 bg-orange-100 rounded-full flex items-center justify-center">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                >
                  <Upload className="w-10 h-10 text-orange-500" />
                </motion.div>
              </div>
            ) : (
              <div className="w-20 h-20 bg-orange-100 rounded-full flex items-center justify-center">
                <Upload className="w-10 h-10 text-orange-500" />
              </div>
            )}
          </motion.div>

          <div>
            <h4 className="text-xl font-semibold text-gray-800 mb-2">
              {photos.length >= maxPhotos ? 'Upload Complete!' : 
               isUploading ? 'Uploading...' : 
               'Upload Your Photos'}
            </h4>
            <p className="text-gray-600 mb-3">
              {photos.length >= maxPhotos 
                ? `You've uploaded all ${maxPhotos} photos`
                : `Add ${maxPhotos - photos.length} more photo${maxPhotos - photos.length !== 1 ? 's' : ''} (${photos.length}/${maxPhotos})`
              }
            </p>
            <div className="text-sm text-gray-500 space-y-1">
              <p>• Drag & drop files or click to browse</p>
              <p>• JPEG, PNG, WebP formats supported</p>
              <p>• Maximum {maxFileSize}MB per image</p>
              <p>• Minimum 400x400 pixels recommended</p>
            </div>
          </div>

          {canUploadMore && (
            <div className="flex justify-center space-x-4">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                type="button"
                className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all"
              >
                <Camera className="w-5 h-5" />
                <span>Take Photos</span>
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                type="button"
                className="flex items-center space-x-2 px-6 py-3 border-2 border-gray-300 text-gray-700 rounded-xl font-semibold hover:border-orange-400 hover:text-orange-600 transition-all"
              >
                <ImageIcon className="w-5 h-5" />
                <span>Choose Files</span>
              </motion.button>
            </div>
          )}
        </div>
      </div>

      {/* Upload Progress */}
      <AnimatePresence>
        {uploadProgress.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-3"
          >
            <h4 className="font-semibold text-gray-800">Upload Progress</h4>
            {uploadProgress.map((item) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="bg-white border border-gray-200 rounded-xl p-4 shadow-sm"
              >
                <div className="flex items-center space-x-4">
                  <div className="w-16 h-16 bg-gray-100 rounded-xl overflow-hidden flex-shrink-0">
                    <img
                      src={URL.createObjectURL(item.file)}
                      alt="Upload preview"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-800 truncate">
                      {item.file.name}
                    </p>
                    <p className="text-xs text-gray-500 mb-2">
                      {(item.file.size / (1024 * 1024)).toFixed(1)}MB
                    </p>
                    <div className="flex items-center space-x-3">
                      <div className="flex-1 bg-gray-200 rounded-full h-2">
                        <motion.div
                          className={`h-2 rounded-full transition-all ${
                            item.status === 'completed' ? 'bg-green-500' :
                            item.status === 'error' ? 'bg-red-500' :
                            'bg-gradient-to-r from-orange-500 to-red-500'
                          }`}
                          initial={{ width: 0 }}
                          animate={{ width: `${item.progress}%` }}
                          transition={{ duration: 0.3 }}
                        />
                      </div>
                      <span className="text-xs text-gray-500 min-w-[3rem]">
                        {item.status === 'completed' ? 'Done!' :
                         item.status === 'error' ? 'Failed' :
                         `${Math.round(item.progress)}%`}
                      </span>
                    </div>
                  </div>
                  <div className="flex-shrink-0">
                    {item.status === 'completed' && (
                      <Check className="w-6 h-6 text-green-500" />
                    )}
                    {item.status === 'error' && (
                      <AlertCircle className="w-6 h-6 text-red-500" />
                    )}
                    {item.status === 'uploading' && (
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                        className="w-6 h-6 border-2 border-orange-500 border-t-transparent rounded-full"
                      />
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Photo Grid */}
      {photos.length > 0 && (
        <div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-4"
        >
          <div className="flex items-center justify-between">
            <h4 className="text-xl font-semibold text-gray-800">
              Your Photos ({photos.length}/{maxPhotos})
            </h4>
            <div className="text-sm text-gray-600 bg-gray-100 px-3 py-1 rounded-full">
              {photos.length === 0 ? 'No photos yet' :
               photos.length === 1 ? '1 photo uploaded' :
               `${photos.length} photos uploaded`}
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {photos.map((photo, index) => (
              <motion.div
                key={index}
                layout
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                className="relative group aspect-square bg-gray-100 rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-all"
              >
                <img
                  src={photo}
                  alt={`Photo ${index + 1}`}
                  className="w-full h-full object-cover"
                />
                
                {/* Photo Overlay */}
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-all" />
                
                {/* Main Photo Badge */}
                {index === 0 && (
                  <div className="absolute top-2 left-2 bg-gradient-to-r from-orange-500 to-red-500 text-white px-3 py-1 rounded-full text-xs font-bold shadow-lg">
                    MAIN
                  </div>
                )}

                {/* Photo Number */}
                <div className="absolute top-2 right-2 bg-black/70 text-white w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold">
                  {index + 1}
                </div>

                {/* Action Buttons */}
                <div className="absolute bottom-2 right-2 flex space-x-1 opacity-0 group-hover:opacity-100 transition-all">
                  {index > 0 && (
                    <motion.button
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      onClick={() => reorderPhotos(index, 0)}
                      className="w-8 h-8 bg-blue-500 text-white rounded-full flex items-center justify-center shadow-lg"
                      title="Make main photo"
                    >
                      <Star className="w-4 h-4" />
                    </motion.button>
                  )}
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => removePhoto(index)}
                    className="w-8 h-8 bg-red-500 text-white rounded-full flex items-center justify-center shadow-lg"
                    title="Remove photo"
                  >
                    <X className="w-4 h-4" />
                  </motion.button>
                </div>

                {/* Drag Handle */}
                <div className="absolute inset-0 cursor-move opacity-0 group-hover:opacity-100 transition-all" />
              </motion.div>
            ))}

            {/* Add More Photos Placeholder */}
            {photos.length < maxPhotos && !isUploading && (
              <motion.div
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => fileInputRef.current?.click()}
                className="aspect-square border-2 border-dashed border-gray-300 rounded-2xl flex flex-col items-center justify-center cursor-pointer hover:border-orange-400 hover:bg-orange-50 transition-all"
              >
                <Plus className="w-8 h-8 text-gray-400 mb-2" />
                <span className="text-sm text-gray-500 font-medium">Add Photo</span>
                <span className="text-xs text-gray-400">
                  {maxPhotos - photos.length} remaining
                </span>
              </motion.div>
            )}
          </div>

          {/* Photo Tips */}
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
            <h5 className="font-semibold text-blue-800 mb-2">📸 Photo Tips for Better Matches</h5>
            <ul className="text-sm text-blue-700 space-y-1">
              <li>• Use high-quality, well-lit photos</li>
              <li>• Include a clear main photo of yourself</li>
              <li>• Show your personality and interests</li>
              <li>• Avoid group photos as your main image</li>
              <li>• First photo appears in swipe cards</li>
            </ul>
          </div>
        </div>
      )}

      {/* Upload Requirements */}
      <div className="bg-gray-50 border border-gray-200 rounded-xl p-4">
        <h5 className="font-semibold text-gray-800 mb-2">Upload Requirements</h5>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm text-gray-600">
          <div className="flex items-center space-x-2">
            <Check className="w-4 h-4 text-green-500" />
            <span>JPEG, PNG, WebP formats</span>
          </div>
          <div className="flex items-center space-x-2">
            <Check className="w-4 h-4 text-green-500" />
            <span>Maximum {maxFileSize}MB per file</span>
          </div>
          <div className="flex items-center space-x-2">
            <Check className="w-4 h-4 text-green-500" />
            <span>Minimum 400x400 pixels</span>
          </div>
          <div className="flex items-center space-x-2">
            <Check className="w-4 h-4 text-green-500" />
            <span>Up to {maxPhotos} photos total</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PhotoUpload;