import React from 'react';
import { motion } from 'framer-motion';
import { Home, User } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const RoleSelection: React.FC = () => {
  const navigate = useNavigate();

  const handleRoleSelect = (role: 'client' | 'owner') => {
    navigate(`/auth/${role}`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-500 via-red-500 to-orange-500 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        {/* Logo */}
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
          className="mb-8"
        >
          <div className="w-20 h-20 mx-auto bg-white rounded-full flex items-center justify-center shadow-2xl">
            <div className="w-12 h-12 bg-gradient-to-br from-orange-400 to-red-500 rounded-full flex items-center justify-center">
              <span className="text-white font-bold text-xl">🔥</span>
            </div>
          </div>
        </motion.div>

        {/* Title */}
        <motion.h1
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="text-6xl font-bold text-white mb-4 tracking-tight"
        >
          TINDERENT
        </motion.h1>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="text-xl text-white/90 mb-12 max-w-md mx-auto"
        >
          Find your perfect rental property or tenant with ease.
        </motion.p>

        {/* Role Selection Buttons */}
        <div className="space-y-4 max-w-sm mx-auto">
          <motion.button
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.8 }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => handleRoleSelect('client')}
            className="w-full bg-gradient-to-r from-orange-400 to-orange-500 text-white py-5 px-8 rounded-full font-semibold text-lg shadow-xl hover:shadow-2xl transition-all duration-300 flex items-center justify-center space-x-3 active:scale-95"
          >
            <User className="w-6 h-6" />
            <span>I'm a Client</span>
          </motion.button>

          <motion.button
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 1 }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => handleRoleSelect('owner')}
            className="w-full bg-gradient-to-r from-red-500 to-red-600 text-white py-5 px-8 rounded-full font-semibold text-lg shadow-xl hover:shadow-2xl transition-all duration-300 flex items-center justify-center space-x-3 active:scale-95"
          >
            <Home className="w-6 h-6" />
            <span>I'm an Owner</span>
          </motion.button>
        </div>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2 }}
          className="text-white/70 text-sm mt-8"
        >
          Choose your role to get started
        </motion.p>
      </motion.div>
    </div>
  );
};

export default RoleSelection;