import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Home, MessageCircle, BarChart3, User, Settings, Zap, Users } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useTheme } from '../../contexts/ThemeContext';
import { supabase, Listing } from '../../lib/supabase';
import PropertyForm from './PropertyForm';
import PropertyList from './PropertyList';
import OwnerMatches from './OwnerMatches';
import OwnerAnalytics from './OwnerAnalytics';
import OwnerProfile from './OwnerProfile';
import PremiumModal from '../subscription/PremiumModal';
import OwnerSettings from './OwnerSettings';
import ClientMatchingDashboard from './ClientMatchingDashboard';
import ColorModeToggle from '../common/ColorModeToggle';

const OwnerDashboard: React.FC = () => {
  const { profile, signOut } = useAuth();
  const { colorMode } = useTheme();
  const [activeTab, setActiveTab] = useState('properties');
  const [showPropertyForm, setShowPropertyForm] = useState(false);
  const [showPremium, setShowPremium] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [properties, setProperties] = useState<Listing[]>([]);
  const [stats, setStats] = useState({
    totalProperties: 0,
    totalViews: 0,
    totalLikes: 0,
    totalMatches: 0
  });

  const isPremium = profile?.subscription_status === 'premium';

  useEffect(() => {
    fetchProperties();
    fetchStats();
  }, [profile]);

  const fetchProperties = async () => {
    if (!profile) return;

    try {
      const { data, error } = await supabase
        .from('listings')
        .select(`
          *,
          owner:profiles(*)
        `)
        .eq('owner_id', profile.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setProperties(data || []);
    } catch (error) {
      console.error('Error fetching properties:', error);
    }
  };

  const fetchStats = async () => {
    if (!profile) return;

    try {
      // Get property stats
      const { data: propertyStats } = await supabase
        .from('listings')
        .select('view_count, likes')
        .eq('owner_id', profile.id);

      // Get matches count
      const { count: matchesCount } = await supabase
        .from('matches')
        .select('*', { count: 'exact' })
        .eq('owner_id', profile.id);

      const totalViews = propertyStats?.reduce((sum, prop) => sum + (prop.view_count || 0), 0) || 0;
      const totalLikes = propertyStats?.reduce((sum, prop) => sum + (prop.likes || 0), 0) || 0;

      setStats({
        totalProperties: properties.length,
        totalViews,
        totalLikes,
        totalMatches: matchesCount || 0
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
      toast.error('Failed to load statistics');
    }
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'properties':
        return <PropertyList properties={properties} onRefresh={fetchProperties} />;
      case 'clients':
        return <ClientMatchingDashboard />;
      case 'matches':
        return <OwnerMatches />;
      case 'analytics':
        return <OwnerAnalytics stats={stats} />;
      case 'profile':
        return <OwnerProfile />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-br from-orange-400 to-red-500 rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-xl">🔥</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-800">Tinderent</h1>
                <p className="text-gray-600">Owner Dashboard</p>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              {!isPremium && (
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setShowPremium(true)}
                  className="bg-yellow-400 text-black px-4 py-2 rounded-full text-sm font-semibold flex items-center space-x-2"
                >
                  <Zap className="w-4 h-4" />
                  <span>Upgrade</span>
                </motion.button>
              )}

              <ColorModeToggle size="md" showLabel={false} />

              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setShowPropertyForm(true)}
                className="bg-gradient-to-r from-orange-500 to-red-500 text-white px-4 py-2 rounded-full font-semibold flex items-center space-x-2"
              >
                <Plus className="w-4 h-4" />
                <span>Add Property</span>
              </motion.button>
            </div>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-4 gap-4 mt-6">
            <div className="bg-blue-50 rounded-xl p-4 text-center">
              <div className="text-2xl font-bold text-blue-600">{stats.totalProperties}</div>
              <div className="text-sm text-blue-600">Properties</div>
            </div>
            <div className="bg-green-50 rounded-xl p-4 text-center">
              <div className="text-2xl font-bold text-green-600">{stats.totalViews}</div>
              <div className="text-sm text-green-600">Views</div>
            </div>
            <div className="bg-red-50 rounded-xl p-4 text-center">
              <div className="text-2xl font-bold text-red-600">{stats.totalLikes}</div>
              <div className="text-sm text-red-600">Likes</div>
            </div>
            <div className="bg-purple-50 rounded-xl p-4 text-center">
              <div className="text-2xl font-bold text-purple-600">{stats.totalMatches}</div>
              <div className="text-sm text-purple-600">Matches</div>
            </div>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="bg-white border-b border-gray-200">
        <div className="flex overflow-x-auto">
          {[
            { id: 'properties', label: 'Properties', icon: Home },
            { id: 'clients', label: 'Find Clients', icon: Users },
            { id: 'matches', label: 'Matches', icon: MessageCircle },
            { id: 'analytics', label: 'Analytics', icon: BarChart3 },
            { id: 'profile', label: 'Profile', icon: User }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center space-x-2 px-6 py-4 border-b-2 transition-all whitespace-nowrap ${
                activeTab === tab.id
                  ? 'border-orange-500 text-orange-600'
                  : 'border-transparent text-gray-600 hover:text-gray-800'
              }`}
            >
              <tab.icon className="w-5 h-5" />
              <span className="font-medium">{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Tab Content */}
      <div className="flex-1">
        {renderTabContent()}
      </div>

      {/* Modals */}
      <AnimatePresence>
        {showPropertyForm && (
          <PropertyForm
            onClose={() => setShowPropertyForm(false)}
            onSuccess={() => {
              setShowPropertyForm(false);
              fetchProperties();
            }}
          />
        )}

        {showPremium && (
          <PremiumModal
            userType="owner"
            onClose={() => setShowPremium(false)}
          />
        )}

        {showSettings && (
          <OwnerSettings
            onClose={() => setShowSettings(false)}
          />
        )}
      </AnimatePresence>

      {/* Bottom Navigation (Mobile) */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-3">
        <div className="flex justify-around items-center">
          <button
            onClick={() => setActiveTab('properties')}
            className={`flex flex-col items-center space-y-1 transition-colors ${
              activeTab === 'properties' ? 'text-orange-500' : 'text-gray-600'
            }`}
          >
            <Home className="w-6 h-6" />
            <span className="text-xs">Properties</span>
          </button>

          <button
            onClick={() => setActiveTab('matches')}
            className={`flex flex-col items-center space-y-1 transition-colors ${
              activeTab === 'matches' ? 'text-orange-500' : 'text-gray-600'
            }`}
          >
            <MessageCircle className="w-6 h-6" />
            <span className="text-xs">Matches</span>
          </button>

          <button
            onClick={() => setActiveTab('analytics')}
            className={`flex flex-col items-center space-y-1 transition-colors ${
              activeTab === 'analytics' ? 'text-orange-500' : 'text-gray-600'
            }`}
          >
            <BarChart3 className="w-6 h-6" />
            <span className="text-xs">Analytics</span>
          </button>

          <button
            onClick={() => setShowSettings(true)}
            className="flex flex-col items-center space-y-1 text-gray-600 hover:text-orange-500 transition-colors"
          >
            <Settings className="w-6 h-6" />
            <span className="text-xs">Settings</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default OwnerDashboard;