import React from 'react';
import { motion } from 'framer-motion';
import { MapPin, Eye, Heart, Edit, Trash2, MoreVertical } from 'lucide-react';
import { Listing } from '../../lib/supabase';

interface PropertyListProps {
  properties: Listing[];
  onRefresh: () => void;
}

const PropertyList: React.FC<PropertyListProps> = ({ properties, onRefresh }) => {
  if (properties.length === 0) {
    return (
      <div className="p-6">
        <div className="text-center py-20">
          <div className="w-16 h-16 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
            <span className="text-2xl">🏠</span>
          </div>
          <h3 className="text-xl font-semibold text-gray-600 mb-2">No properties yet</h3>
          <p className="text-gray-500 mb-6">Start by adding your first property listing</p>
          <button className="bg-gradient-to-r from-orange-500 to-red-500 text-white px-6 py-3 rounded-full font-semibold">
            Add Property
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="grid gap-6">
        {properties.map((property, index) => (
          <motion.div
            key={property.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-all"
          >
            <div className="flex">
              {/* Property Image */}
              <div className="w-48 h-32 flex-shrink-0">
                <img
                  src={property.images?.[0] || 'https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg'}
                  alt={property.title}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Property Info */}
              <div className="flex-1 p-4">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-800 mb-1">
                      {property.title}
                    </h3>
                    <div className="flex items-center text-gray-600 text-sm">
                      <MapPin className="w-4 h-4 mr-1" />
                      <span>{property.address}</span>
                    </div>
                  </div>
                  <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                    <MoreVertical className="w-4 h-4 text-gray-600" />
                  </button>
                </div>

                <div className="flex items-center justify-between">
                  <div className="text-2xl font-bold text-orange-500">
                    ${property.price?.toLocaleString() || '0'}
                    <span className="text-sm text-gray-600 font-normal">
                      /{property.listing_type === 'rent' ? 'month' : 'total'}
                    </span>
                  </div>

                  <div className="flex items-center space-x-4 text-sm text-gray-600">
                    <div className="flex items-center space-x-1">
                      <Eye className="w-4 h-4" />
                      <span>{property.view_count || 0}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Heart className="w-4 h-4" />
                      <span>{property.likes || 0}</span>
                    </div>
                  </div>
                </div>

                {/* Property Details */}
                <div className="flex items-center space-x-4 mt-3 text-sm text-gray-600">
                  {property.beds && (
                    <span>{property.beds} bed</span>
                  )}
                  {property.baths && (
                    <span>{property.baths} bath</span>
                  )}
                  {property.square_footage && (
                    <span>{property.square_footage} sqft</span>
                  )}
                  <span className="capitalize">{property.property_type}</span>
                </div>

                {/* Status Badge */}
                <div className="mt-3">
                  <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${
                    property.is_active 
                      ? 'bg-green-100 text-green-800' 
                      : 'bg-gray-100 text-gray-600'
                  }`}>
                    {property.is_active ? 'Active' : 'Inactive'}
                  </span>
                  {property.is_featured && (
                    <span className="ml-2 inline-block px-3 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                      Featured
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="px-4 py-3 bg-gray-50 border-t border-gray-200">
              <div className="flex justify-end space-x-2">
                <button className="flex items-center space-x-1 px-3 py-2 text-gray-600 hover:text-gray-800 transition-colors">
                  <Edit className="w-4 h-4" />
                  <span className="text-sm">Edit</span>
                </button>
                <button className="flex items-center space-x-1 px-3 py-2 text-red-600 hover:text-red-800 transition-colors">
                  <Trash2 className="w-4 h-4" />
                  <span className="text-sm">Delete</span>
                </button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default PropertyList;