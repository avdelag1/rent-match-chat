import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  X, User, MapPin, DollarSign, Calendar, Briefcase, 
  Phone, Mail, Star, Check, Heart, MessageCircle,
  Home, Clock, Shield, Award
} from 'lucide-react';
import { Profile } from '../../lib/supabase';

interface ClientDetailsModalProps {
  client: Profile;
  onClose: () => void;
  onLike?: () => void;
  onPass?: () => void;
  onSuperLike?: () => void;
  onContact?: () => void;
}

const ClientDetailsModal: React.FC<ClientDetailsModalProps> = ({ 
  client, 
  onClose, 
  onLike, 
  onPass, 
  onSuperLike, 
  onContact 
}) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const images = client.images || [
    'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg'
  ];

  const compatibilityScore = 85; // This would be calculated based on matching algorithm

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 z-50 flex items-end"
      onClick={onClose}
    >
      <motion.div
        initial={{ y: '100%' }}
        animate={{ y: 0 }}
        exit={{ y: '100%' }}
        transition={{ type: 'spring', damping: 25, stiffness: 200 }}
        className="w-full bg-white rounded-t-3xl max-h-[90vh] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200">
          <h2 className="text-xl font-bold text-gray-800">Client Profile</h2>
          <button
            onClick={onClose}
            className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center"
          >
            <X className="w-5 h-5 text-gray-600" />
          </button>
        </div>

        <div className="overflow-y-auto max-h-[calc(90vh-160px)]">
          {/* Client Photos */}
          <div className="relative h-80">
            <img
              src={images[currentImageIndex]}
              alt={client.full_name}
              className="w-full h-full object-cover"
            />
            
            {/* Photo Navigation */}
            {images.length > 1 && (
              <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
                {images.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentImageIndex(index)}
                    className={`w-2 h-2 rounded-full transition-all ${
                      index === currentImageIndex ? 'bg-white' : 'bg-white/50'
                    }`}
                  />
                ))}
              </div>
            )}

            {/* Compatibility Score */}
            <div className="absolute top-4 right-4 bg-white/95 backdrop-blur-sm px-4 py-2 rounded-full shadow-lg">
              <div className="flex items-center space-x-2">
                <div className={`w-3 h-3 rounded-full ${
                  compatibilityScore >= 80 ? 'bg-green-500' :
                  compatibilityScore >= 60 ? 'bg-yellow-500' : 'bg-red-500'
                }`} />
                <span className="text-sm font-bold text-gray-800">
                  {compatibilityScore}% Match
                </span>
              </div>
            </div>

            {/* Verification Badges */}
            <div className="absolute top-4 left-4 flex flex-col space-y-2">
              {client.verified && (
                <div className="bg-blue-500 text-white px-3 py-1 rounded-full text-xs font-semibold flex items-center space-x-1">
                  <Shield className="w-3 h-3" />
                  <span>Verified</span>
                </div>
              )}
              {client.has_references && (
                <div className="bg-green-500 text-white px-3 py-1 rounded-full text-xs font-semibold flex items-center space-x-1">
                  <Award className="w-3 h-3" />
                  <span>References</span>
                </div>
              )}
            </div>
          </div>

          {/* Client Information */}
          <div className="p-6 space-y-6">
            {/* Basic Info */}
            <div>
              <h1 className="text-3xl font-bold text-gray-800 mb-2">
                {client.full_name}
              </h1>
              <div className="flex items-center space-x-4 text-gray-600">
                <span className="flex items-center space-x-1">
                  <User className="w-4 h-4" />
                  <span>{client.age} years old</span>
                </span>
                <span className="flex items-center space-x-1">
                  <Briefcase className="w-4 h-4" />
                  <span className="capitalize">{client.occupation}</span>
                </span>
              </div>
            </div>

            {/* Budget & Timeline */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-green-50 rounded-xl p-4">
                <div className="flex items-center space-x-2 mb-2">
                  <DollarSign className="w-5 h-5 text-green-600" />
                  <span className="font-semibold text-green-800">Budget Range</span>
                </div>
                <div className="text-2xl font-bold text-green-700">
                  ${client.budget_min?.toLocaleString() || '0'} - ${client.budget_max?.toLocaleString() || '0'}
                </div>
                <div className="text-sm text-green-600">per month</div>
              </div>

              <div className="bg-blue-50 rounded-xl p-4">
                <div className="flex items-center space-x-2 mb-2">
                  <Calendar className="w-5 h-5 text-blue-600" />
                  <span className="font-semibold text-blue-800">Move-in Date</span>
                </div>
                <div className="text-lg font-bold text-blue-700">
                  {client.ideal_move_in_date 
                    ? new Date(client.ideal_move_in_date).toLocaleDateString()
                    : 'Flexible'
                  }
                </div>
                <div className="text-sm text-blue-600">
                  {client.flexible_dates ? 'Flexible timing' : 'Fixed date'}
                </div>
              </div>
            </div>

            {/* Property Preferences */}
            <div>
              <h3 className="text-lg font-semibold text-gray-800 mb-3">Property Preferences</h3>
              <div className="space-y-3">
                <div>
                  <span className="text-sm font-medium text-gray-700">Looking for:</span>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {client.preferred_property_types?.map((type, index) => (
                      <span key={index} className="bg-orange-100 text-orange-700 px-3 py-1 rounded-full text-sm font-medium capitalize">
                        {type}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="font-medium text-gray-700">Bedrooms:</span>
                    <span className="ml-2 text-gray-600">
                      {client.min_bedrooms || 0}+ bedrooms
                    </span>
                  </div>
                  <div>
                    <span className="font-medium text-gray-700">Bathrooms:</span>
                    <span className="ml-2 text-gray-600">
                      {client.min_bathrooms || 1}+ bathrooms
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* About Section */}
            {client.bio && (
              <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-3">About {client.full_name}</h3>
                <p className="text-gray-700 leading-relaxed">{client.bio}</p>
              </div>
            )}

            {/* Lifestyle & Preferences */}
            <div>
              <h3 className="text-lg font-semibold text-gray-800 mb-3">Lifestyle & Preferences</h3>
              <div className="space-y-4">
                {/* Lifestyle Tags */}
                {client.lifestyle_tags && client.lifestyle_tags.length > 0 && (
                  <div>
                    <span className="text-sm font-medium text-gray-700">Lifestyle:</span>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {client.lifestyle_tags.map((tag, index) => (
                        <span key={index} className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-sm capitalize">
                          {tag.replace('_', ' ')}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Policies */}
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <div className={`w-3 h-3 rounded-full ${client.has_pets ? 'bg-orange-500' : 'bg-green-500'}`} />
                      <span className="text-gray-700">
                        {client.has_pets ? 'Has pets' : 'No pets'}
                      </span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className={`w-3 h-3 rounded-full ${client.smoking ? 'bg-red-500' : 'bg-green-500'}`} />
                      <span className="text-gray-700">
                        {client.smoking ? 'Smoker' : 'Non-smoker'}
                      </span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <div className={`w-3 h-3 rounded-full ${client.party_friendly ? 'bg-yellow-500' : 'bg-green-500'}`} />
                      <span className="text-gray-700">
                        {client.party_friendly ? 'Social/parties' : 'Quiet lifestyle'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Contact Information */}
            <div>
              <h3 className="text-lg font-semibold text-gray-800 mb-3">Contact Information</h3>
              <div className="space-y-3">
                <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-xl">
                  <Mail className="w-5 h-5 text-gray-500" />
                  <span className="text-gray-700">{client.email}</span>
                </div>
                {client.phone && (
                  <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-xl">
                    <Phone className="w-5 h-5 text-gray-500" />
                    <span className="text-gray-700">{client.phone}</span>
                  </div>
                )}
                <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-xl">
                  <MapPin className="w-5 h-5 text-gray-500" />
                  <span className="text-gray-700">{client.location}</span>
                </div>
              </div>
            </div>

            {/* Languages */}
            {client.languages_spoken && client.languages_spoken.length > 0 && (
              <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-3">Languages</h3>
                <div className="flex flex-wrap gap-2">
                  {client.languages_spoken.map((language, index) => (
                    <span key={index} className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm capitalize">
                      {language}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Action Footer */}
        <div className="p-6 border-t border-gray-200 bg-gray-50">
          <div className="flex space-x-3">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={onPass}
              className="flex-1 py-3 border border-gray-300 rounded-xl text-gray-700 font-semibold hover:bg-gray-100 transition-colors flex items-center justify-center space-x-2"
            >
              <X className="w-5 h-5" />
              <span>Pass</span>
            </motion.button>

            {onSuperLike && (
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={onSuperLike}
                className="px-4 py-3 bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-xl font-semibold hover:shadow-lg transition-all flex items-center justify-center"
              >
                <Star className="w-5 h-5" />
              </motion.button>
            )}

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={onLike}
              className="flex-1 py-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-xl font-semibold hover:shadow-lg transition-all flex items-center justify-center space-x-2"
            >
              <Heart className="w-5 h-5" />
              <span>Like</span>
            </motion.button>
          </div>

          {onContact && (
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={onContact}
              className="w-full mt-3 py-3 bg-orange-500 text-white rounded-xl font-semibold hover:shadow-lg transition-all flex items-center justify-center space-x-2"
            >
              <MessageCircle className="w-5 h-5" />
              <span>Start Conversation</span>
            </motion.button>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
};

export default ClientDetailsModal;