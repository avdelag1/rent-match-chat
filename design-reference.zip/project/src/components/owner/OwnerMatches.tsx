import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { MessageCircle, User, Clock, Heart } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { supabase, Match } from '../../lib/supabase';
import ChatModal from '../messaging/ChatModal';

const OwnerMatches: React.FC = () => {
  const { profile } = useAuth();
  const [matches, setMatches] = useState<Match[]>([]);
  const [selectedMatch, setSelectedMatch] = useState<Match | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchMatches();
  }, [profile]);

  const fetchMatches = async () => {
    if (!profile) return;

    try {
      const { data, error } = await supabase
        .from('matches')
        .select(`
          *,
          client:profiles!matches_client_id_fkey(*),
          property:properties(*)
        `)
        .eq('owner_id', profile.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setMatches(data || []);
    } catch (error) {
      console.error('Error fetching matches:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="p-6 flex items-center justify-center h-64">
        <div className="w-8 h-8 border-2 border-orange-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <>
      <div className="p-6">
        {matches.length === 0 ? (
          <div className="text-center py-20">
            <Heart className="w-16 h-16 mx-auto mb-4 text-gray-300" />
            <h3 className="text-xl font-semibold text-gray-600 mb-2">No matches yet</h3>
            <p className="text-gray-500">When clients like your properties, matches will appear here</p>
          </div>
        ) : (
          <div className="space-y-4">
            <h2 className="text-xl font-bold text-gray-800 mb-6">Your Matches</h2>
            
            {matches.map((match) => (
              <motion.div
                key={match.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white border border-gray-200 rounded-2xl p-6 shadow-sm hover:shadow-md transition-all"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    {/* Client Avatar */}
                    <div className="w-16 h-16 bg-gradient-to-br from-blue-400 to-purple-500 rounded-full flex items-center justify-center">
                      <span className="text-white font-bold text-xl">
                        {match.client?.full_name?.charAt(0) || 'C'}
                      </span>
                    </div>

                    {/* Match Info */}
                    <div>
                      <h3 className="text-lg font-semibold text-gray-800">
                        {match.client?.full_name}
                      </h3>
                      <p className="text-gray-600 text-sm mb-1">
                        Interested in: {match.property?.title}
                      </p>
                      <div className="flex items-center text-xs text-gray-500">
                        <Clock className="w-3 h-3 mr-1" />
                        <span>
                          Matched {new Date(match.created_at).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center space-x-3">
                    <button
                      onClick={() => setSelectedMatch(match)}
                      className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-xl hover:shadow-lg transition-all"
                    >
                      <MessageCircle className="w-4 h-4" />
                      <span>Chat</span>
                    </button>
                  </div>
                </div>

                {/* Client Details */}
                {match.client?.bio && (
                  <div className="mt-4 p-4 bg-gray-50 rounded-xl">
                    <h4 className="font-medium text-gray-800 mb-2">About {match.client.full_name}</h4>
                    <p className="text-gray-600 text-sm">{match.client.bio}</p>
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        )}
      </div>

      {/* Chat Modal */}
      {selectedMatch && (
        <ChatModal
          match={selectedMatch}
          onClose={() => setSelectedMatch(null)}
        />
      )}
    </>
  );
};

export default OwnerMatches;