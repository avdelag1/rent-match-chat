import React from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, Eye, Heart, MessageCircle, Home } from 'lucide-react';

interface OwnerAnalyticsProps {
  stats: {
    totalProperties: number;
    totalViews: number;
    totalLikes: number;
    totalMatches: number;
  };
}

const OwnerAnalytics: React.FC<OwnerAnalyticsProps> = ({ stats }) => {
  const analyticsCards = [
    {
      title: 'Total Properties',
      value: stats.totalProperties,
      icon: Home,
      color: 'blue',
      change: '+12%'
    },
    {
      title: 'Total Views',
      value: stats.totalViews,
      icon: Eye,
      color: 'green',
      change: '+8%'
    },
    {
      title: 'Total Likes',
      value: stats.totalLikes,
      icon: Heart,
      color: 'red',
      change: '+15%'
    },
    {
      title: 'Total Matches',
      value: stats.totalMatches,
      icon: MessageCircle,
      color: 'purple',
      change: '+23%'
    }
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      blue: 'bg-blue-50 text-blue-600 border-blue-200',
      green: 'bg-green-50 text-green-600 border-green-200',
      red: 'bg-red-50 text-red-600 border-red-200',
      purple: 'bg-purple-50 text-purple-600 border-purple-200'
    };
    return colors[color as keyof typeof colors] || colors.blue;
  };

  return (
    <div className="p-6">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Analytics Overview</h2>
        <p className="text-gray-600">Track your property performance and engagement</p>
      </div>

      {/* Analytics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {analyticsCards.map((card, index) => (
          <motion.div
            key={card.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className={`p-6 rounded-2xl border-2 ${getColorClasses(card.color)}`}
          >
            <div className="flex items-center justify-between mb-4">
              <card.icon className="w-8 h-8" />
              <span className="text-sm font-medium text-green-600 bg-green-100 px-2 py-1 rounded-full">
                {card.change}
              </span>
            </div>
            <div className="text-3xl font-bold mb-1">{card.value}</div>
            <div className="text-sm opacity-80">{card.title}</div>
          </motion.div>
        ))}
      </div>

      {/* Performance Chart Placeholder */}
      <div className="bg-white rounded-2xl border border-gray-200 p-6 mb-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-800">Performance Trends</h3>
          <div className="flex items-center space-x-2">
            <TrendingUp className="w-5 h-5 text-green-500" />
            <span className="text-sm text-green-600 font-medium">+15% this month</span>
          </div>
        </div>
        
        <div className="h-64 bg-gray-50 rounded-xl flex items-center justify-center">
          <div className="text-center text-gray-500">
            <TrendingUp className="w-12 h-12 mx-auto mb-4 text-gray-300" />
            <p>Performance chart coming soon</p>
            <p className="text-sm">Upgrade to Premium for detailed analytics</p>
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-white rounded-2xl border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Recent Activity</h3>
        
        <div className="space-y-4">
          {[
            { action: 'New like on "Modern Downtown Apartment"', time: '2 hours ago', type: 'like' },
            { action: 'Property view increased by 15%', time: '5 hours ago', type: 'view' },
            { action: 'New match with Sarah Johnson', time: '1 day ago', type: 'match' },
            { action: 'Property "Cozy Studio" went live', time: '2 days ago', type: 'property' }
          ].map((activity, index) => (
            <div key={index} className="flex items-center space-x-3 p-3 hover:bg-gray-50 rounded-xl transition-colors">
              <div className={`w-2 h-2 rounded-full ${
                activity.type === 'like' ? 'bg-red-500' :
                activity.type === 'view' ? 'bg-green-500' :
                activity.type === 'match' ? 'bg-purple-500' :
                'bg-blue-500'
              }`} />
              <div className="flex-1">
                <p className="text-gray-800 text-sm">{activity.action}</p>
                <p className="text-gray-500 text-xs">{activity.time}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default OwnerAnalytics;