import React, { useState } from 'react';
import { motion, PanInfo, useMotionValue, useTransform } from 'framer-motion';
import { Heart, X, Star, MapPin, DollarSign, Calendar, Briefcase, User, Phone, Mail } from 'lucide-react';
import { Profile } from '../../lib/supabase';

interface ClientSwipeCardProps {
  client: Profile;
  onSwipe: (direction: 'left' | 'right') => void;
  onTap: () => void;
  onSuperLike?: () => void;
  isPremium?: boolean;
}

const ClientSwipeCard: React.FC<ClientSwipeCardProps> = ({ 
  client, 
  onSwipe, 
  onTap, 
  onSuperLike,
  isPremium = false 
}) => {
  const [exitX, setExitX] = useState(0);
  const x = useMotionValue(0);
  const rotate = useTransform(x, [-200, 200], [-30, 30]);
  const opacity = useTransform(x, [-200, -150, 0, 150, 200], [0, 1, 1, 1, 0]);

  const handleDragEnd = (event: any, info: PanInfo) => {
    const threshold = 100;
    
    if (info.offset.x > threshold) {
      setExitX(200);
      onSwipe('right');
    } else if (info.offset.x < -threshold) {
      setExitX(-200);
      onSwipe('left');
    }
  };

  const mainImage = client.images?.[0] || `https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg`;

  return (
    <motion.div
      className="absolute inset-0 cursor-grab active:cursor-grabbing"
      style={{ x, rotate, opacity }}
      drag="x"
      dragConstraints={{ left: 0, right: 0 }}
      onDragEnd={handleDragEnd}
      animate={exitX !== 0 ? { x: exitX } : {}}
    >
      <div className="w-full h-full bg-white rounded-3xl shadow-2xl overflow-hidden relative flex flex-col">
        {/* Client Photo Section - 50% height */}
        <div className="relative h-[50%] flex-shrink-0">
          <img
            src={mainImage}
            alt={client.full_name}
            className="w-full h-full object-cover"
          />
          
          {/* Gradient Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/20" />
          
          {/* Verified Badge */}
          {client.broker_verified && (
            <div className="absolute top-4 right-4 bg-blue-500 text-white px-3 py-1 rounded-full text-sm font-semibold flex items-center space-x-1 shadow-lg">
              <Star className="w-4 h-4" />
              <span>Verified</span>
            </div>
          )}

          {/* Budget Badge */}
          <div className="absolute top-4 left-4 bg-white/95 backdrop-blur-sm px-4 py-2 rounded-full shadow-lg">
            <span className="text-lg font-bold text-gray-800">
              ${client.budget_min?.toLocaleString() || '0'} - ${client.budget_max?.toLocaleString() || '0'}
            </span>
          </div>

          {/* Client Name Overlay */}
          <div className="absolute bottom-4 left-4 text-white">
            <h2 className="text-2xl font-bold mb-1">{client.full_name}</h2>
            <div className="flex items-center space-x-2 text-sm">
              <span>{client.age}</span>
              <span>•</span>
              <span className="capitalize">{client.occupation}</span>
            </div>
          </div>
        </div>

        {/* Client Info Section - 35% height */}
        <div className="flex-1 p-6 flex flex-col justify-between min-h-0">
          <div className="space-y-4">
            {/* Location & Contact */}
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center space-x-2 text-gray-600">
                <MapPin className="w-4 h-4 flex-shrink-0" />
                <span className="text-sm truncate">{client.location || 'Location not specified'}</span>
              </div>
              <div className="flex items-center space-x-2 text-gray-600">
                <Calendar className="w-4 h-4 flex-shrink-0" />
                <span className="text-sm">
                  {client.ideal_move_in_date 
                    ? new Date(client.ideal_move_in_date).toLocaleDateString()
                    : 'Flexible'
                  }
                </span>
              </div>
            </div>

            {/* Property Preferences */}
            <div>
              <h4 className="font-semibold text-gray-800 mb-2">Looking For:</h4>
              <div className="flex flex-wrap gap-2">
                {client.preferred_property_types?.slice(0, 3).map((type, index) => (
                  <span key={index} className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-medium">
                    {type}
                  </span>
                ))}
                {(client.preferred_property_types?.length || 0) > 3 && (
                  <span className="bg-gray-100 text-gray-600 px-3 py-1 rounded-full text-sm">
                    +{(client.preferred_property_types?.length || 0) - 3} more
                  </span>
                )}
              </div>
            </div>

            {/* Client Bio */}
            {client.bio && (
              <div>
                <p className="text-gray-700 text-sm line-clamp-3 leading-relaxed">
                  {client.bio}
                </p>
              </div>
            )}

            {/* Lifestyle Tags */}
            {client.lifestyle_tags && client.lifestyle_tags.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {client.lifestyle_tags.slice(0, 4).map((tag, index) => (
                  <span key={index} className="bg-green-100 text-green-700 px-2 py-1 rounded-full text-xs">
                    {tag}
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Action Buttons Section - 15% height */}
        <div className="h-[15%] min-h-[80px] bg-white border-t border-gray-100 flex items-center justify-center px-8 py-4">
          <div className="flex items-center justify-center space-x-8 w-full max-w-xs">
            {/* Pass Button */}
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={(e) => {
                e.stopPropagation();
                onSwipe('left');
              }}
              className="w-16 h-16 bg-gray-100 hover:bg-gray-200 rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-all duration-200 border-2 border-gray-200"
            >
              <X className="w-7 h-7 text-gray-600" />
            </motion.button>

            {/* Super Like Button (Premium only) */}
            {isPremium && onSuperLike && (
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={(e) => {
                  e.stopPropagation();
                  onSuperLike();
                }}
                className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-all duration-200"
              >
                <Star className="w-5 h-5 text-white" />
              </motion.button>
            )}

            {/* Like Button */}
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={(e) => {
                e.stopPropagation();
                onSwipe('right');
              }}
              className="w-16 h-16 bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-all duration-200"
            >
              <Heart className="w-7 h-7 text-white" />
            </motion.button>
          </div>
        </div>

        {/* Swipe Indicators */}
        <motion.div
          className="absolute top-1/2 left-8 transform -translate-y-1/2 bg-red-500 text-white px-6 py-3 rounded-full font-bold text-xl border-4 border-white shadow-lg"
          style={{
            opacity: useTransform(x, [-150, -50], [1, 0])
          }}
        >
          PASS
        </motion.div>

        <motion.div
          className="absolute top-1/2 right-8 transform -translate-y-1/2 bg-green-500 text-white px-6 py-3 rounded-full font-bold text-xl border-4 border-white shadow-lg"
          style={{
            opacity: useTransform(x, [50, 150], [0, 1])
          }}
        >
          LIKE
        </motion.div>
      </div>
    </motion.div>
  );
};

export default ClientSwipeCard;