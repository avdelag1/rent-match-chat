import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Filter, Users, Heart, X, Star, Zap } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useTheme } from '../../contexts/ThemeContext';
import { supabase, Profile } from '../../lib/supabase';
import ClientSwipeCard from './ClientSwipeCard';
import ClientFilterModal from './ClientFilterModal';
import PremiumModal from '../subscription/PremiumModal';
import ColorModeToggle from '../common/ColorModeToggle';
import toast from 'react-hot-toast';

const ClientMatchingDashboard: React.FC = () => {
  const { profile } = useAuth();
  const { colorMode } = useTheme();
  const [clients, setClients] = useState<Profile[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showFilters, setShowFilters] = useState(false);
  const [showPremium, setShowPremium] = useState(false);
  const [loading, setLoading] = useState(true);
  const [swipeCount, setSwipeCount] = useState(0);
  const [filters, setFilters] = useState<any>({});

  const currentClient = clients[currentIndex];
  const dailySwipeLimit = 30; // Free owners get 30 client swipes per day
  const isPremium = profile?.package === 'premium' || profile?.package === 'unlimited';

  useEffect(() => {
    if (profile) {
      fetchClients();
      fetchTodaySwipeCount();
    }
  }, [profile, filters]);

  const fetchClients = async () => {
    if (!profile) return;

    try {
      let query = supabase
        .from('profiles')
        .select('*')
        .eq('role', 'client')
        .eq('is_active', true)
        .eq('onboarding_completed', true)
        .neq('id', profile?.id); // Don't show own profile

      // Apply filters
      if (filters.budgetRange) {
        query = query.gte('budget_min', filters.budgetRange[0]).lte('budget_max', filters.budgetRange[1]);
      }
      if (filters.ageRange) {
        query = query.gte('age', filters.ageRange[0]).lte('age', filters.ageRange[1]);
      }
      if (filters.location) {
        query = query.ilike('location', `%${filters.location}%`);
      }
      if (filters.occupation) {
        query = query.eq('occupation', filters.occupation);
      }
      if (filters.verified) {
        query = query.eq('verified', true);
      }
      if (filters.hasReferences) {
        query = query.eq('has_references', true);
      }

      const { data, error } = await query.order('created_at', { ascending: false });

      if (error) throw error;
      setClients(data || []);
    } catch (error) {
      console.error('Error fetching clients:', error);
      toast.error('Failed to load clients');
    } finally {
      setLoading(false);
    }
  };

  const fetchTodaySwipeCount = async () => {
    if (!profile) return;

    try {
      const today = new Date().toISOString().split('T')[0];
      const { count } = await supabase
        .from('owner_likes')
        .select('*', { count: 'exact' })
        .eq('owner_id', profile.id)
        .gte('created_at', today);

      setSwipeCount(count || 0);
    } catch (error) {
      console.error('Error fetching swipe count:', error);
      setSwipeCount(0);
    }
  };

  const handleSwipe = async (direction: 'left' | 'right') => {
    if (!currentClient || !profile) return;

    // Check swipe limit for non-premium users
    if (!isPremium && swipeCount >= dailySwipeLimit) {
      setShowPremium(true);
      return;
    }

    try {
      // Record the owner's like/pass
      const { error } = await supabase
        .from('owner_likes')
        .insert({
          owner_id: profile.id,
          client_id: currentClient.id,
          listing_id: null // Can be specific to a listing later
        });

      if (error) throw error;

      setSwipeCount(prev => prev + 1);

      // Check for match if liked
      if (direction === 'right') {
        await checkForMatch(currentClient);
      }

      // Move to next client
      setCurrentIndex(prev => prev + 1);
    } catch (error) {
      console.error('Error recording swipe:', error);
      toast.error('Failed to record swipe');
    }
  };

  const checkForMatch = async (client: Profile) => {
    if (!profile) return;

    try {
      // Check if client has liked this owner back
      const { data: clientLike } = await supabase
        .from('swipes')
        .select('*')
        .eq('user_id', client.id)
        .eq('target_id', profile?.id)
        .eq('target_type', 'profile')
        .eq('action', 'like')
        .maybeSingle();

      if (clientLike) {
        // Create match
        const { error } = await supabase
          .from('matches')
          .insert({
            client_id: client.id,
            owner_id: profile?.id,
            listing_id: null,
            is_mutual: true
          });

        if (!error) {
          toast.success('🎉 It\'s a match!');
        }
      }
    } catch (error) {
      console.error('Error checking for match:', error);
    }
  };

  const handleSuperLike = async () => {
    if (!currentClient || !profile) return;

    // Check if user has premium access
    if (!isPremium) {
      setShowPremium(true);
      return;
    }

    try {
      const { error } = await supabase
        .from('owner_likes')
        .insert({
          owner_id: profile.id,
          client_id: currentClient.id,
          listing_id: null,
          is_super_like: true
        });

      if (error) throw error;

      setSwipeCount(prev => prev + 1);
      await checkForMatch(currentClient);
      setCurrentIndex(prev => prev + 1);
      toast.success('⭐ Super Like sent!');
    } catch (error) {
      console.error('Error sending super like:', error);
      toast.error('Failed to send super like');
    }
  };

  const handleApplyFilters = (newFilters: any) => {
    setFilters(newFilters);
    setCurrentIndex(0);
    setShowFilters(false);
    toast.success('Filters applied');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-500 via-red-500 to-pink-500 flex items-center justify-center">
        <div className="text-white text-center">
          <div className="w-16 h-16 border-4 border-white border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-xl">Loading potential clients...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-500 via-red-500 to-pink-500">
      {/* Header */}
      <div className="flex items-center justify-between p-4 pt-12">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center">
            <span className="text-xl">🔥</span>
          </div>
          <div className="text-white">
            <h1 className="text-xl font-bold">Client Matching</h1>
            <p className="text-sm opacity-80">
              {swipeCount}/{isPremium ? '∞' : dailySwipeLimit} swipes today
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <ColorModeToggle size="md" showLabel={false} />
          <button
            onClick={() => setShowFilters(true)}
            className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center"
          >
            <Filter className="w-5 h-5 text-white" />
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="px-4 pb-24">
        {currentIndex < clients.length ? (
          <div className="relative h-[600px] max-w-sm mx-auto">
            <AnimatePresence>
              {clients.slice(currentIndex, currentIndex + 3).map((client, index) => (
                <motion.div
                  key={client.id}
                  className="absolute inset-0"
                  style={{ zIndex: 3 - index }}
                  initial={{ scale: 1 - index * 0.05, y: index * 10 }}
                  animate={{ scale: 1 - index * 0.05, y: index * 10 }}
                >
                  {index === 0 ? (
                    <ClientSwipeCard
                      client={client}
                      onSwipe={handleSwipe}
                      onTap={() => {/* Show client details */}}
                      onSuperLike={handleSuperLike}
                      isPremium={isPremium}
                    />
                  ) : (
                    <div className="w-full h-full bg-white rounded-3xl shadow-xl overflow-hidden">
                      <img
                        src={client.images?.[0] || 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg'}
                        alt={client.full_name}
                        className="w-full h-3/5 object-cover"
                      />
                      <div className="p-6">
                        <h3 className="text-xl font-bold text-gray-800 mb-2">
                          {client.full_name}
                        </h3>
                        <div className="flex items-center text-gray-600">
                          <span className="text-sm">{client.occupation}</span>
                        </div>
                      </div>
                    </div>
                  )}
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        ) : (
          <div className="text-center text-white py-20">
            <Users className="w-16 h-16 mx-auto mb-4 opacity-50" />
            <h2 className="text-2xl font-bold mb-2">No more clients!</h2>
            <p className="opacity-80 mb-6">Adjust your filters or check back later</p>
            <button
              onClick={() => {
                setCurrentIndex(0);
                fetchClients();
              }}
              className="bg-white text-orange-500 px-6 py-3 rounded-full font-semibold"
            >
              Refresh
            </button>
          </div>
        )}
      </div>

      {/* Stats Footer */}
      <div className="fixed bottom-0 left-0 right-0 bg-white/10 backdrop-blur-sm border-t border-white/20 px-4 py-3">
        <div className="flex justify-center items-center space-x-8 max-w-sm mx-auto text-white">
          <div className="text-center">
            <div className="text-lg font-bold">{clients.length}</div>
            <div className="text-xs opacity-80">Potential Clients</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-bold">{swipeCount}</div>
            <div className="text-xs opacity-80">Swipes Today</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-bold">
              {isPremium ? '∞' : dailySwipeLimit - swipeCount}
            </div>
            <div className="text-xs opacity-80">Remaining</div>
          </div>
        </div>
      </div>

      {/* Modals */}
      <AnimatePresence>
        {showFilters && (
          <ClientFilterModal
            onClose={() => setShowFilters(false)}
            onApplyFilters={handleApplyFilters}
          />
        )}

        {showPremium && (
          <PremiumModal
            userType="owner"
            onClose={() => setShowPremium(false)}
          />
        )}
      </AnimatePresence>
    </div>
  );
};

export default ClientMatchingDashboard;