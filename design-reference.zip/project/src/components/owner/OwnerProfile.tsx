import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Edit3, User, Mail, Phone, MapPin, Calendar, Camera, Star } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

const OwnerProfile: React.FC = () => {
  const { profile, updateProfile } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    full_name: profile?.full_name || '',
    phone: profile?.phone || '',
    location: profile?.location || '',
    age: profile?.age?.toString() || '',
    bio: profile?.bio || ''
  });

  const handleSave = async () => {
    try {
      await updateProfile({
        ...formData,
        age: formData.age ? parseInt(formData.age) : undefined
      });
      setIsEditing(false);
    } catch (error) {
      console.error('Error updating profile:', error);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const isPremium = profile?.package === 'premium' || profile?.package === 'unlimited';

  return (
    <div className="p-6 max-w-2xl mx-auto">
      {/* Profile Header */}
      <div className="bg-white rounded-2xl border border-gray-200 p-8 mb-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-gray-800">Profile Settings</h2>
          {isEditing ? (
            <div className="flex items-center space-x-2">
              <button
                onClick={() => setIsEditing(false)}
                className="px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                className="px-4 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors"
              >
                Save Changes
              </button>
            </div>
          ) : (
            <button
              onClick={() => setIsEditing(true)}
              className="flex items-center space-x-2 px-4 py-2 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
            >
              <Edit3 className="w-4 h-4" />
              <span>Edit Profile</span>
            </button>
          )}
        </div>

        {/* Profile Picture */}
        <div className="text-center mb-8">
          <div className="relative inline-block">
            <div className="w-32 h-32 bg-gradient-to-br from-orange-400 to-red-500 rounded-full flex items-center justify-center text-white text-4xl font-bold">
              {profile?.full_name?.charAt(0) || 'O'}
            </div>
            {isEditing && (
              <button className="absolute bottom-2 right-2 w-10 h-10 bg-white rounded-full shadow-lg flex items-center justify-center border-2 border-gray-200">
                <Camera className="w-5 h-5 text-gray-600" />
              </button>
            )}
          </div>
          <h3 className="text-2xl font-bold text-gray-800 mt-4">
            {profile?.full_name}
          </h3>
          <div className="flex items-center justify-center space-x-2 mt-2">
            <span className="text-gray-600 capitalize">{profile?.role}</span>
            {isPremium && (
              <span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs font-semibold flex items-center space-x-1">
                <Star className="w-3 h-3" />
                <span>Premium</span>
              </span>
            )}
          </div>
        </div>

        {/* Profile Form */}
        <div className="space-y-6">
          {/* Full Name */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Full Name
            </label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                name="full_name"
                value={formData.full_name}
                onChange={handleInputChange}
                disabled={!isEditing}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all disabled:bg-gray-50"
              />
            </div>
          </div>

          {/* Email (Read Only) */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Email Address
            </label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="email"
                value={profile?.email || ''}
                disabled
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl bg-gray-50 text-gray-500"
              />
            </div>
          </div>

          {/* Phone */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Phone Number
            </label>
            <div className="relative">
              <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={handleInputChange}
                disabled={!isEditing}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all disabled:bg-gray-50"
              />
            </div>
          </div>

          {/* Location and Age */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Location
              </label>
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  name="location"
                  value={formData.location}
                  onChange={handleInputChange}
                  disabled={!isEditing}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all disabled:bg-gray-50"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Age
              </label>
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="number"
                  name="age"
                  value={formData.age}
                  onChange={handleInputChange}
                  disabled={!isEditing}
                  min="18"
                  max="100"
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all disabled:bg-gray-50"
                />
              </div>
            </div>
          </div>

          {/* Bio */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Bio
            </label>
            <textarea
              name="bio"
              value={formData.bio}
              onChange={handleInputChange}
              disabled={!isEditing}
              rows={4}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all resize-none disabled:bg-gray-50"
              placeholder="Tell potential tenants about yourself and your properties..."
            />
          </div>
        </div>
      </div>

      {/* Subscription Status */}
      <div className="bg-white rounded-2xl border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Subscription & Benefits</h3>
        
        <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
          <div>
            <div className="flex items-center space-x-2 mb-1">
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                isPremium 
                  ? 'bg-yellow-100 text-yellow-800' 
                  : 'bg-gray-100 text-gray-600'
              }`}>
                {isPremium ? 'Premium Owner' : 'Free Plan'}
              </span>
            </div>
            <p className="text-gray-600 text-sm">
              {isPremium 
                ? 'Enjoy unlimited listings and premium features' 
                : 'Upgrade to unlock all owner features'
              }
            </p>
          </div>
          
          {!isPremium && (
            <button className="bg-gradient-to-r from-orange-500 to-red-500 text-white px-4 py-2 rounded-lg font-semibold hover:shadow-lg transition-all">
              Upgrade Now
            </button>
          )}
        </div>

        {/* Benefits List */}
        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
          {[
            { feature: 'Unlimited Property Listings', premium: true },
            { feature: 'Advanced Analytics', premium: true },
            { feature: 'Featured Listings', premium: true },
            { feature: 'Priority Support', premium: true },
            { feature: 'Basic Listings (up to 3)', premium: false },
            { feature: 'Standard Support', premium: false }
          ].map((benefit, index) => (
            <div
              key={index}
              className={`flex items-center space-x-3 p-3 rounded-xl ${
                benefit.premium && !isPremium ? 'bg-gray-50 opacity-50' : 'bg-green-50'
              }`}
            >
              <div className={`w-2 h-2 rounded-full ${
                benefit.premium && isPremium ? 'bg-green-500' :
                !benefit.premium ? 'bg-green-500' : 'bg-gray-300'
              }`} />
              <span className={`text-sm ${
                benefit.premium && !isPremium ? 'text-gray-500' : 'text-gray-700'
              }`}>
                {benefit.feature}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default OwnerProfile;