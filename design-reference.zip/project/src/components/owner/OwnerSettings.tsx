import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  X, 
  User, 
  Bell, 
  Shield, 
  CreditCard, 
  BarChart3,
  Home,
  MessageCircle,
  Settings as SettingsIcon,
  Moon,
  Sun,
  Globe,
  HelpCircle,
  LogOut,
  ChevronRight,
  Palette
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useTheme } from '../../contexts/ThemeContext';
import PremiumModal from '../subscription/PremiumModal';
import ColorModeToggle from '../common/ColorModeToggle';

interface OwnerSettingsProps {
  onClose: () => void;
}

const OwnerSettings: React.FC<OwnerSettingsProps> = ({ onClose }) => {
  const { profile, signOut, updateProfile } = useAuth();
  const { colorMode } = useTheme();
  const [showPremium, setShowPremium] = useState(false);
  const [activeSection, setActiveSection] = useState<string | null>(null);
  const [settings, setSettings] = useState({
    notifications: {
      newLikes: true,
      messages: true,
      propertyViews: true,
      analytics: true,
      promotions: false
    },
    privacy: {
      showContactInfo: false,
      allowDirectMessages: true,
      profileVisibility: 'public',
      showPropertyStats: true
    },
    business: {
      autoResponder: false,
      responseTemplate: '',
      businessHours: {
        enabled: false,
        start: '09:00',
        end: '18:00'
      },
      propertyVisibility: 'high'
    },
    preferences: {
      theme: 'light',
      language: 'en',
      currency: 'USD',
      timezone: 'UTC'
    }
  });

  const isPremium = profile?.package === 'premium';

  const handleSettingChange = (section: string, key: string, value: any) => {
    setSettings(prev => ({
      ...prev,
      [section]: {
        ...prev[section as keyof typeof prev],
        [key]: value
      }
    }));
  };

  const handleSaveSettings = async () => {
    try {
      await updateProfile({
        notification_preferences: settings.notifications,
        privacy_settings: settings.privacy,
        business_settings: settings.business,
        app_preferences: settings.preferences
      });
    } catch (error) {
      console.error('Error saving settings:', error);
    }
  };

  const settingSections = [
    {
      id: 'account',
      title: 'Account',
      icon: User,
      items: [
        { label: 'Edit Profile', action: () => setActiveSection('profile') },
        { label: 'Subscription', action: () => setShowPremium(true), premium: !isPremium },
        { label: 'Business Verification', action: () => setActiveSection('verification') },
        { label: 'Payment Methods', action: () => setActiveSection('payments') }
      ]
    },
    {
      id: 'properties',
      title: 'Property Management',
      icon: Home,
      items: [
        { label: 'Property Settings', action: () => setActiveSection('properties') },
        { label: 'Listing Templates', action: () => setActiveSection('templates'), premium: !isPremium },
        { label: 'Auto-Responses', action: () => setActiveSection('autoresponse'), premium: !isPremium },
        { 
          label: 'Property Visibility', 
          type: 'select', 
          value: settings.business.propertyVisibility,
          options: [
            { value: 'low', label: 'Low' },
            { value: 'medium', label: 'Medium' },
            { value: 'high', label: 'High' },
            { value: 'premium', label: 'Premium Boost' }
          ],
          onChange: (value: string) => handleSettingChange('business', 'propertyVisibility', value),
          premium: value => value === 'premium' && !isPremium
        }
      ]
    },
    {
      id: 'notifications',
      title: 'Notifications',
      icon: Bell,
      items: [
        { 
          label: 'New Likes', 
          type: 'toggle', 
          value: settings.notifications.newLikes,
          onChange: (value: boolean) => handleSettingChange('notifications', 'newLikes', value)
        },
        { 
          label: 'Messages', 
          type: 'toggle', 
          value: settings.notifications.messages,
          onChange: (value: boolean) => handleSettingChange('notifications', 'messages', value)
        },
        { 
          label: 'Property Views', 
          type: 'toggle', 
          value: settings.notifications.propertyViews,
          onChange: (value: boolean) => handleSettingChange('notifications', 'propertyViews', value)
        },
        { 
          label: 'Analytics Reports', 
          type: 'toggle', 
          value: settings.notifications.analytics,
          onChange: (value: boolean) => handleSettingChange('notifications', 'analytics', value),
          premium: !isPremium
        }
      ]
    },
    {
      id: 'privacy',
      title: 'Privacy & Safety',
      icon: Shield,
      items: [
        { 
          label: 'Show Contact Info', 
          type: 'toggle', 
          value: settings.privacy.showContactInfo,
          onChange: (value: boolean) => handleSettingChange('privacy', 'showContactInfo', value)
        },
        { 
          label: 'Allow Direct Messages', 
          type: 'toggle', 
          value: settings.privacy.allowDirectMessages,
          onChange: (value: boolean) => handleSettingChange('privacy', 'allowDirectMessages', value)
        },
        { 
          label: 'Show Property Stats', 
          type: 'toggle', 
          value: settings.privacy.showPropertyStats,
          onChange: (value: boolean) => handleSettingChange('privacy', 'showPropertyStats', value),
          premium: !isPremium
        },
        { label: 'Blocked Users', action: () => setActiveSection('blocked') },
        { label: 'Report a Problem', action: () => setActiveSection('report') }
      ]
    },
    {
      id: 'appearance',
      title: 'Appearance',
      icon: Palette,
      items: [
        { 
          label: 'Color Mode', 
          type: 'custom',
          component: () => (
            <div className="flex items-center justify-between py-3">
              <span className="text-gray-700">Interface Color Mode</span>
              <ColorModeToggle size="sm" showLabel={true} />
            </div>
          )
        }
      ]
    }
  ];

  const renderSettingItem = (item: any) => {
    if (item.type === 'toggle') {
      const isDisabled = item.premium && !isPremium;
      return (
        <div className={`flex items-center justify-between py-3 ${isDisabled ? 'opacity-50' : ''}`}>
          <div className="flex items-center space-x-2">
            <span className="text-gray-700">{item.label}</span>
            {item.premium && !isPremium && (
              <span className="text-xs bg-orange-100 text-orange-600 px-2 py-1 rounded-full">Premium</span>
            )}
          </div>
          <button
            onClick={() => !isDisabled && item.onChange(!item.value)}
            disabled={isDisabled}
            className={`relative w-12 h-6 rounded-full transition-colors ${
              item.value && !isDisabled ? 'bg-orange-500' : 'bg-gray-300'
            }`}
          >
            <div
              className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${
                item.value && !isDisabled ? 'translate-x-7' : 'translate-x-1'
              }`}
            />
          </button>
        </div>
      );
    }

    if (item.type === 'select') {
      return (
        <div className="py-3">
          <label className="block text-gray-700 mb-2">{item.label}</label>
          <select
            value={item.value}
            onChange={(e) => item.onChange(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
          >
            {item.options.map((option: any) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
      );
    }

    if (item.type === 'custom' && item.component) {
      return item.component();
    }

    return (
      <button
        onClick={item.action}
        className="flex items-center justify-between py-3 w-full text-left hover:bg-gray-50 rounded-lg px-2 transition-colors"
      >
        <span className={`${item.premium ? 'text-orange-500 font-medium' : 'text-gray-700'}`}>
          {item.label}
          {item.premium && <span className="ml-2 text-xs bg-orange-100 text-orange-600 px-2 py-1 rounded-full">Premium</span>}
        </span>
        <ChevronRight className="w-4 h-4 text-gray-400" />
      </button>
    );
  };

  return (
    <>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 z-50 flex items-end"
        onClick={onClose}
      >
        <motion.div
          initial={{ y: '100%' }}
          animate={{ y: 0 }}
          exit={{ y: '100%' }}
          transition={{ type: 'spring', damping: 25, stiffness: 200 }}
          className="w-full bg-white rounded-t-3xl max-h-[90vh] overflow-hidden"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-gray-200">
            <h2 className="text-xl font-bold text-gray-800">Owner Settings</h2>
            <button
              onClick={onClose}
              className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center"
            >
              <X className="w-5 h-5 text-gray-600" />
            </button>
          </div>

          <div className="overflow-y-auto max-h-[calc(90vh-140px)]">
            {/* User Info */}
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center space-x-4">
                <div className="w-16 h-16 bg-gradient-to-br from-orange-400 to-red-500 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-xl">
                    {profile?.full_name?.charAt(0) || 'O'}
                  </span>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-800">{profile?.full_name}</h3>
                  <p className="text-gray-600">{profile?.email}</p>
                  <div className="flex items-center space-x-2 mt-1">
                    <span className="text-sm text-gray-500 capitalize">{profile?.role}</span>
                    {isPremium && (
                      <span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs font-semibold">
                        Premium
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Settings Sections */}
            <div className="p-6 space-y-6">
              {settingSections.map((section) => (
                <div key={section.id} className="space-y-3">
                  <div className="flex items-center space-x-3 mb-4">
                    <section.icon className="w-5 h-5 text-orange-500" />
                    <h3 className="text-lg font-semibold text-gray-800">{section.title}</h3>
                  </div>
                  
                  <div className="bg-gray-50 rounded-xl p-4 space-y-2">
                    {section.items.map((item, index) => (
                      <div key={index}>
                        {renderSettingItem(item)}
                      </div>
                    ))}
                  </div>
                </div>
              ))}

              {/* Help & Support */}
              <div className="space-y-3">
                <div className="flex items-center space-x-3 mb-4">
                  <HelpCircle className="w-5 h-5 text-orange-500" />
                  <h3 className="text-lg font-semibold text-gray-800">Help & Support</h3>
                </div>
                
                <div className="bg-gray-50 rounded-xl p-4 space-y-2">
                  <button className="flex items-center justify-between py-3 w-full text-left hover:bg-gray-100 rounded-lg px-2 transition-colors">
                    <span className="text-gray-700">Owner Resources</span>
                    <ChevronRight className="w-4 h-4 text-gray-400" />
                  </button>
                  <button className="flex items-center justify-between py-3 w-full text-left hover:bg-gray-100 rounded-lg px-2 transition-colors">
                    <span className="text-gray-700">Property Guidelines</span>
                    <ChevronRight className="w-4 h-4 text-gray-400" />
                  </button>
                  <button className="flex items-center justify-between py-3 w-full text-left hover:bg-gray-100 rounded-lg px-2 transition-colors">
                    <span className="text-gray-700">Contact Support</span>
                    <ChevronRight className="w-4 h-4 text-gray-400" />
                  </button>
                  <button className="flex items-center justify-between py-3 w-full text-left hover:bg-gray-100 rounded-lg px-2 transition-colors">
                    <span className="text-gray-700">Terms of Service</span>
                    <ChevronRight className="w-4 h-4 text-gray-400" />
                  </button>
                </div>
              </div>

              {/* Logout Section */}
              <div className="pt-4 border-t border-gray-200">
                <button
                  onClick={signOut}
                  className="flex items-center space-x-3 w-full py-3 px-4 text-red-600 hover:bg-red-50 rounded-xl transition-colors"
                >
                  <LogOut className="w-5 h-5" />
                  <span className="font-medium">Sign Out</span>
                </button>
              </div>
            </div>
          </div>

          {/* Save Button */}
          <div className="p-6 border-t border-gray-200 bg-gray-50">
            <button
              onClick={handleSaveSettings}
              className="w-full bg-gradient-to-r from-orange-500 to-red-500 text-white py-3 rounded-xl font-semibold hover:shadow-lg transition-all"
            >
              Save Settings
            </button>
          </div>
        </motion.div>
      </motion.div>

      {/* Premium Modal */}
      {showPremium && (
        <PremiumModal
          userType="owner"
          onClose={() => setShowPremium(false)}
        />
      )}
    </>
  );
};

export default OwnerSettings;