import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, DollarSign, MapPin, Calendar, Briefcase, Filter, Star, Users } from 'lucide-react';

interface ClientFilterModalProps {
  onClose: () => void;
  onApplyFilters: (filters: any) => void;
}

const ClientFilterModal: React.FC<ClientFilterModalProps> = ({ onClose, onApplyFilters }) => {
  const [filters, setFilters] = useState({
    budgetRange: [0, 100000],
    ageRange: [18, 65],
    location: '',
    radius: 25,
    propertyTypes: [] as string[],
    moveInDate: '',
    flexibleDates: false,
    verified: false,
    hasReferences: false,
    occupation: '',
    lifestyle: [] as string[],
    petFriendly: '',
    smoking: '',
    partyFriendly: '',
    creditScore: '',
    employmentType: '',
    incomeRange: '',
    languages: [] as string[],
    nationality: ''
  });

  const propertyTypes = [
    'apartment', 'house', 'studio', 'penthouse', 'room', 'commercial'
  ];

  const lifestyleTags = [
    'quiet', 'social', 'professional', 'student', 'remote_worker', 
    'early_riser', 'night_owl', 'fitness_enthusiast', 'foodie', 'traveler'
  ];

  const occupations = [
    'student', 'professional', 'freelancer', 'entrepreneur', 'remote_worker',
    'artist', 'teacher', 'healthcare', 'tech', 'finance', 'other'
  ];

  const languages = [
    'english', 'spanish', 'french', 'german', 'italian', 'portuguese', 'mandarin'
  ];

  const handleApply = () => {
    onApplyFilters(filters);
    onClose();
  };

  const handleReset = () => {
    setFilters({
      budgetRange: [0, 100000],
      ageRange: [18, 65],
      location: '',
      radius: 25,
      propertyTypes: [],
      moveInDate: '',
      flexibleDates: false,
      verified: false,
      hasReferences: false,
      occupation: '',
      lifestyle: [],
      petFriendly: '',
      smoking: '',
      partyFriendly: '',
      creditScore: '',
      employmentType: '',
      incomeRange: '',
      languages: [],
      nationality: ''
    });
  };

  const toggleArrayFilter = (array: string[], value: string, setter: (arr: string[]) => void) => {
    if (array.includes(value)) {
      setter(array.filter(item => item !== value));
    } else {
      setter([...array, value]);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 z-50 flex items-end"
      onClick={onClose}
    >
      <motion.div
        initial={{ y: '100%' }}
        animate={{ y: 0 }}
        exit={{ y: '100%' }}
        transition={{ type: 'spring', damping: 25, stiffness: 200 }}
        className="w-full bg-white rounded-t-3xl max-h-[90vh] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center space-x-3">
            <Filter className="w-6 h-6 text-orange-500" />
            <h2 className="text-xl font-bold text-gray-800">Client Filters</h2>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center"
          >
            <X className="w-5 h-5 text-gray-600" />
          </button>
        </div>

        <div className="overflow-y-auto max-h-[calc(90vh-140px)] p-6 space-y-6">
          {/* Budget Range */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Client Budget Range
            </label>
            <div className="flex items-center space-x-4">
              <div className="flex-1">
                <div className="relative">
                  <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <input
                    type="number"
                    value={filters.budgetRange[0]}
                    onChange={(e) => setFilters(prev => ({
                      ...prev,
                      budgetRange: [parseInt(e.target.value) || 0, prev.budgetRange[1]]
                    }))}
                    className="w-full pl-9 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                    placeholder="Min budget"
                  />
                </div>
              </div>
              <span className="text-gray-500">to</span>
              <div className="flex-1">
                <div className="relative">
                  <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <input
                    type="number"
                    value={filters.budgetRange[1]}
                    onChange={(e) => setFilters(prev => ({
                      ...prev,
                      budgetRange: [prev.budgetRange[0], parseInt(e.target.value) || 100000]
                    }))}
                    className="w-full pl-9 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                    placeholder="Max budget"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Age Range */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Age Range
            </label>
            <div className="flex items-center space-x-4">
              <div className="flex-1">
                <input
                  type="number"
                  value={filters.ageRange[0]}
                  onChange={(e) => setFilters(prev => ({
                    ...prev,
                    ageRange: [parseInt(e.target.value) || 18, prev.ageRange[1]]
                  }))}
                  min="18"
                  max="100"
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  placeholder="Min age"
                />
              </div>
              <span className="text-gray-500">to</span>
              <div className="flex-1">
                <input
                  type="number"
                  value={filters.ageRange[1]}
                  onChange={(e) => setFilters(prev => ({
                    ...prev,
                    ageRange: [prev.ageRange[0], parseInt(e.target.value) || 65]
                  }))}
                  min="18"
                  max="100"
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  placeholder="Max age"
                />
              </div>
            </div>
          </div>

          {/* Location & Radius */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Location Preferences
            </label>
            <div className="space-y-3">
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input
                  type="text"
                  value={filters.location}
                  onChange={(e) => setFilters(prev => ({ ...prev, location: e.target.value }))}
                  className="w-full pl-9 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  placeholder="City, State or specific area"
                />
              </div>
              <div>
                <label className="block text-xs text-gray-600 mb-2">
                  Search radius: {filters.radius} miles
                </label>
                <input
                  type="range"
                  min="5"
                  max="100"
                  value={filters.radius}
                  onChange={(e) => setFilters(prev => ({ ...prev, radius: parseInt(e.target.value) }))}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                />
              </div>
            </div>
          </div>

          {/* Property Type Preferences */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Property Type Interest
            </label>
            <div className="grid grid-cols-2 gap-2">
              {propertyTypes.map((type) => (
                <button
                  key={type}
                  onClick={() => toggleArrayFilter(
                    filters.propertyTypes, 
                    type, 
                    (arr) => setFilters(prev => ({ ...prev, propertyTypes: arr }))
                  )}
                  className={`p-3 rounded-xl border-2 transition-all capitalize ${
                    filters.propertyTypes.includes(type)
                      ? 'border-orange-500 bg-orange-50 text-orange-700'
                      : 'border-gray-200 text-gray-700 hover:border-gray-300'
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>

          {/* Occupation Filter */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Occupation
            </label>
            <div className="relative">
              <Briefcase className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <select
                value={filters.occupation}
                onChange={(e) => setFilters(prev => ({ ...prev, occupation: e.target.value }))}
                className="w-full pl-9 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              >
                <option value="">Any occupation</option>
                {occupations.map(occupation => (
                  <option key={occupation} value={occupation} className="capitalize">
                    {occupation.replace('_', ' ')}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Lifestyle Preferences */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Lifestyle Compatibility
            </label>
            <div className="grid grid-cols-2 gap-2">
              {lifestyleTags.map((tag) => (
                <button
                  key={tag}
                  onClick={() => toggleArrayFilter(
                    filters.lifestyle, 
                    tag, 
                    (arr) => setFilters(prev => ({ ...prev, lifestyle: arr }))
                  )}
                  className={`p-2 rounded-lg border-2 transition-all text-sm capitalize ${
                    filters.lifestyle.includes(tag)
                      ? 'border-green-500 bg-green-50 text-green-700'
                      : 'border-gray-200 text-gray-700 hover:border-gray-300'
                  }`}
                >
                  {tag.replace('_', ' ')}
                </button>
              ))}
            </div>
          </div>

          {/* Verification & Trust Filters */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Verification & Trust
            </label>
            <div className="space-y-3">
              <label className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  checked={filters.verified}
                  onChange={(e) => setFilters(prev => ({ ...prev, verified: e.target.checked }))}
                  className="w-5 h-5 text-orange-500 border-gray-300 rounded focus:ring-orange-500"
                />
                <span className="text-gray-700">Verified clients only</span>
              </label>

              <label className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  checked={filters.hasReferences}
                  onChange={(e) => setFilters(prev => ({ ...prev, hasReferences: e.target.checked }))}
                  className="w-5 h-5 text-orange-500 border-gray-300 rounded focus:ring-orange-500"
                />
                <span className="text-gray-700">Has references</span>
              </label>
            </div>
          </div>

          {/* Lifestyle Policies */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Lifestyle Policies
            </label>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-gray-600 mb-2">Pet Policy</label>
                <select
                  value={filters.petFriendly}
                  onChange={(e) => setFilters(prev => ({ ...prev, petFriendly: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                >
                  <option value="">Any</option>
                  <option value="true">Has pets</option>
                  <option value="false">No pets</option>
                </select>
              </div>

              <div>
                <label className="block text-xs text-gray-600 mb-2">Smoking</label>
                <select
                  value={filters.smoking}
                  onChange={(e) => setFilters(prev => ({ ...prev, smoking: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                >
                  <option value="">Any</option>
                  <option value="true">Smoker</option>
                  <option value="false">Non-smoker</option>
                </select>
              </div>
            </div>
          </div>

          {/* Employment & Income */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Employment & Financial
            </label>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-gray-600 mb-2">Employment Type</label>
                <select
                  value={filters.employmentType}
                  onChange={(e) => setFilters(prev => ({ ...prev, employmentType: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                >
                  <option value="">Any</option>
                  <option value="full_time">Full-time</option>
                  <option value="part_time">Part-time</option>
                  <option value="freelance">Freelance</option>
                  <option value="student">Student</option>
                  <option value="retired">Retired</option>
                </select>
              </div>

              <div>
                <label className="block text-xs text-gray-600 mb-2">Income Range</label>
                <select
                  value={filters.incomeRange}
                  onChange={(e) => setFilters(prev => ({ ...prev, incomeRange: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                >
                  <option value="">Any income</option>
                  <option value="0-30k">$0 - $30,000</option>
                  <option value="30k-60k">$30,000 - $60,000</option>
                  <option value="60k-100k">$60,000 - $100,000</option>
                  <option value="100k+">$100,000+</option>
                </select>
              </div>
            </div>
          </div>

          {/* Languages */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Languages Spoken
            </label>
            <div className="grid grid-cols-2 gap-2">
              {languages.map((language) => (
                <button
                  key={language}
                  onClick={() => toggleArrayFilter(
                    filters.languages, 
                    language, 
                    (arr) => setFilters(prev => ({ ...prev, languages: arr }))
                  )}
                  className={`p-2 rounded-lg border-2 transition-all text-sm capitalize ${
                    filters.languages.includes(language)
                      ? 'border-blue-500 bg-blue-50 text-blue-700'
                      : 'border-gray-200 text-gray-700 hover:border-gray-300'
                  }`}
                >
                  {language}
                </button>
              ))}
            </div>
          </div>

          {/* Move-in Timeline */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Move-in Timeline
            </label>
            <div className="space-y-3">
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input
                  type="date"
                  value={filters.moveInDate}
                  onChange={(e) => setFilters(prev => ({ ...prev, moveInDate: e.target.value }))}
                  className="w-full pl-9 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                />
              </div>
              <label className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  checked={filters.flexibleDates}
                  onChange={(e) => setFilters(prev => ({ ...prev, flexibleDates: e.target.checked }))}
                  className="w-5 h-5 text-orange-500 border-gray-300 rounded focus:ring-orange-500"
                />
                <span className="text-gray-700">Flexible with dates</span>
              </label>
            </div>
          </div>

          {/* Credit & Background */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Credit & Background
            </label>
            <select
              value={filters.creditScore}
              onChange={(e) => setFilters(prev => ({ ...prev, creditScore: e.target.value }))}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent"
            >
              <option value="">Any credit score</option>
              <option value="excellent">Excellent (750+)</option>
              <option value="good">Good (700-749)</option>
              <option value="fair">Fair (650-699)</option>
              <option value="poor">Poor (below 650)</option>
            </select>
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-gray-200 bg-gray-50">
          <div className="flex space-x-3">
            <button
              onClick={handleReset}
              className="flex-1 py-3 border border-gray-300 rounded-xl text-gray-700 font-semibold hover:bg-gray-100 transition-colors"
            >
              Reset All
            </button>
            <button
              onClick={handleApply}
              className="flex-1 py-3 bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-xl font-semibold hover:shadow-lg transition-all"
            >
              Apply Filters
            </button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default ClientFilterModal;