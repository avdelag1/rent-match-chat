import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './contexts/AuthContext';
import RoleSelection from './components/RoleSelection';
import AuthForm from './components/auth/AuthForm';
import ClientDashboard from './components/client/ClientDashboard';
import OwnerDashboard from './components/owner/OwnerDashboard';
import AdminDashboard from './components/admin/AdminDashboard';
import LoadingScreen from './components/LoadingScreen';

function App() {
  const { user, profile, loading } = useAuth();

  console.log('App: render state -', {
    loading,
    hasUser: !!user,
    hasProfile: !!profile,
    role: profile?.role,
    onboardingComplete: profile?.onboarding_completed,
    currentPath: window.location.pathname
  });

  // Show loading screen while authentication is being determined
  if (loading) {
    console.log('App: Showing loading screen');
    return <LoadingScreen />;
  }

  // If user is authenticated and has a profile, show role-based dashboard
  if (user && profile) {
    console.log('App: User authenticated, role:', profile.role);
    
    return (
      <Routes>
        <Route path="/client/*" element={
          profile.role === 'client' ? <ClientDashboard /> : <Navigate to="/" replace />
        } />
        <Route path="/owner/*" element={
          (profile.role === 'owner' || profile.role === 'broker') ? <OwnerDashboard /> : <Navigate to="/" replace />
        } />
        <Route path="/admin/*" element={
          profile.role === 'admin' ? <AdminDashboard /> : <Navigate to="/" replace />
        } />
        {/* Redirect to appropriate dashboard based on role */}
        <Route path="/" element={
          <Navigate to={`/${profile.role === 'broker' ? 'owner' : profile.role}`} replace />
        } />
        <Route path="/auth/*" element={
          <Navigate to={`/${profile.role === 'broker' ? 'owner' : profile.role}`} replace />
        } />
        <Route path="*" element={
          <Navigate to={`/${profile.role === 'broker' ? 'owner' : profile.role}`} replace />
        } />
      </Routes>
    );
  }

  // If not authenticated, show auth flow
  console.log('App: No user/profile, showing auth flow');
  return (
    <Routes>
      <Route path="/" element={<RoleSelection />} />
      <Route path="/auth/:role" element={<AuthForm />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default App;