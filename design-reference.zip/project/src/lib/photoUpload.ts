import { supabase } from './supabase';
import toast from 'react-hot-toast';

export interface PhotoUploadOptions {
  bucket: 'property-photos' | 'profile-photos';
  folder?: string;
  maxSize?: number;
  allowedTypes?: string[];
}

export interface UploadResult {
  url: string;
  path: string;
  size: number;
}

/**
 * Upload a single photo to Supabase Storage
 */
export const uploadPhoto = async (
  file: File, 
  options: PhotoUploadOptions
): Promise<UploadResult> => {

  const { bucket, folder = '', maxSize = 10 * 1024 * 1024, allowedTypes = ['image/jpeg', 'image/png', 'image/webp'] } = options;

  // Validate file
  if (!allowedTypes.includes(file.type)) {
    throw new Error(`File type ${file.type} is not allowed`);
  }

  if (file.size > maxSize) {
    throw new Error(`File size exceeds ${maxSize / (1024 * 1024)}MB limit`);
  }

  try {
    // Generate unique filename
    const fileExt = file.name.split('.').pop();
    const fileName = `${Date.now()}-${Math.random().toString(36).substring(2)}.${fileExt}`;
    const filePath = folder ? `${folder}/${fileName}` : fileName;

    // Upload to Supabase Storage
    const { data, error } = await supabase.storage
      .from(bucket)
      .upload(filePath, file, {
        cacheControl: '3600',
        upsert: false
      });

    if (error) throw error;

    // Get public URL
    const { data: { publicUrl } } = supabase.storage
      .from(bucket)
      .getPublicUrl(filePath);

    return {
      url: publicUrl,
      path: filePath,
      size: file.size
    };
  } catch (error: any) {
    console.error('Photo upload error:', error);
    throw new Error(`Upload failed: ${error.message}`);
  }
};

/**
 * Upload multiple photos with progress tracking
 */
export const uploadMultiplePhotos = async (
  files: File[],
  options: PhotoUploadOptions,
  onProgress?: (progress: { completed: number; total: number; currentFile?: string }) => void
): Promise<UploadResult[]> => {
  const results: UploadResult[] = [];
  const total = files.length;

  for (let i = 0; i < files.length; i++) {
    const file = files[i];
    
    try {
      onProgress?.({ completed: i, total, currentFile: file.name });
      
      const result = await uploadPhoto(file, options);
      results.push(result);
      
      onProgress?.({ completed: i + 1, total });
    } catch (error: any) {
      console.error(`Failed to upload ${file.name}:`, error);
      toast.error(`Failed to upload ${file.name}: ${error.message}`);
      throw error;
    }
  }

  return results;
};

/**
 * Delete a photo from Supabase Storage
 */
export const deletePhoto = async (bucket: string, path: string): Promise<void> => {

  try {
    const { error } = await supabase.storage
      .from(bucket)
      .remove([path]);

    if (error) throw error;
  } catch (error: any) {
    console.error('Photo deletion error:', error);
    throw new Error(`Delete failed: ${error.message}`);
  }
};

/**
 * Validate image dimensions
 */
export const validateImageDimensions = (file: File): Promise<{ width: number; height: number }> => {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      resolve({ width: img.width, height: img.height });
    };
    img.onerror = () => {
      reject(new Error('Invalid image file'));
    };
    img.src = URL.createObjectURL(file);
  });
};

/**
 * Compress image if needed
 */
export const compressImage = (file: File, maxWidth = 1920, quality = 0.8): Promise<File> => {
  return new Promise((resolve) => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d')!;
    const img = new Image();

    img.onload = () => {
      // Calculate new dimensions
      let { width, height } = img;
      if (width > maxWidth) {
        height = (height * maxWidth) / width;
        width = maxWidth;
      }

      canvas.width = width;
      canvas.height = height;

      // Draw and compress
      ctx.drawImage(img, 0, 0, width, height);
      
      canvas.toBlob(
        (blob) => {
          if (blob) {
            const compressedFile = new File([blob], file.name, {
              type: file.type,
              lastModified: Date.now()
            });
            resolve(compressedFile);
          } else {
            resolve(file);
          }
        },
        file.type,
        quality
      );
    };

    img.src = URL.createObjectURL(file);
  });
};

/**
 * Create upload session for tracking
 */
export const createUploadSession = async (
  userId: string,
  sessionType: 'property' | 'profile',
  targetId: string,
  totalFiles: number
): Promise<string> => {

  try {
    const { data, error } = await supabase
      .from('photo_upload_sessions')
      .insert({
        user_id: userId,
        session_type: sessionType,
        target_id: targetId,
        total_files: totalFiles
      })
      .select('id')
      .single();

    if (error) throw error;
    return data.id;
  } catch (error: any) {
    console.error('Error creating upload session:', error);
    throw error;
  }
};

/**
 * Update upload session progress
 */
export const updateUploadSession = async (
  sessionId: string,
  updates: {
    uploaded_files?: number;
    failed_files?: number;
    status?: 'in_progress' | 'completed' | 'failed' | 'cancelled';
    error_details?: any;
  }
): Promise<void> => {

  try {
    const updateData: any = { ...updates };
    if (updates.status === 'completed' || updates.status === 'failed') {
      updateData.completed_at = new Date().toISOString();
    }

    const { error } = await supabase
      .from('photo_upload_sessions')
      .update(updateData)
      .eq('id', sessionId);

    if (error) throw error;
  } catch (error: any) {
    console.error('Error updating upload session:', error);
  }
};