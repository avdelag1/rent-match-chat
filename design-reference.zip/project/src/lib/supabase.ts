import { createClient } from '@supabase/supabase-js';

// Get environment variables with proper validation
// Check if Supabase is properly configured
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

const isSupabaseConfigured = supabaseUrl && 
  supabaseAnonKey && 
  supabaseUrl !== 'your-project-url' && 
  supabaseAnonKey !== 'your-anon-key' &&
  supabaseUrl.startsWith('https://') &&
  supabaseAnonKey.length > 50;

// Create Supabase client only if properly configured
export const supabase = isSupabaseConfigured 
  ? createClient(supabaseUrl, supabaseAnonKey)
  : null;

// Demo mode flag
export const isDemoMode = !isSupabaseConfigured;

// Database Types based on your schema
export interface Profile {
  id: string;
  email?: string;
  full_name?: string;
  avatar_url?: string;
  role?: 'client' | 'owner' | 'broker' | 'admin';
  phone?: string;
  gender?: string;
  move_in_date?: string;
  preferences?: string[];
  verified?: boolean;
  bio?: string;
  created_at?: string;
  is_active?: boolean;
  location?: string;
  package?: string;
  broker_verified?: boolean;
  broker_tier?: string;
  age?: number;
  occupation?: string;
  nationality?: string;
  languages_spoken?: string[];
  lifestyle_tags?: string[];
  has_pets?: boolean;
  smoking?: boolean;
  party_friendly?: boolean;
  max_stay_preference?: number;
  budget_min?: number;
  budget_max?: number;
  has_references?: boolean;
  images?: string[];
  about_me?: string;
  interests?: string[];
  profession?: string;
  education?: string;
  relationship_status?: string;
  looking_for?: string;
  height?: number;
  exercise_frequency?: string;
  drinking?: string;
  cooking_skills?: string;
  work_schedule?: string;
  social_level?: string;
  preferred_listing_type?: string;
  max_budget?: number;
  preferred_property_types?: string[];
  preferred_locations?: string[];
  min_bedrooms?: number;
  max_bedrooms?: number;
  min_bathrooms?: number;
  max_bathrooms?: number;
  furnished_preference?: string;
  pet_preference?: boolean;
  ideal_move_in_date?: string;
  rental_duration_preference?: string;
  onboarding_completed?: boolean;
  updated_at?: string;
}

export interface Listing {
  id: string;
  owner_id: string;
  title?: string;
  description?: string;
  address?: string;
  images?: string[];
  video_url?: string;
  floorplan_url?: string;
  property_type?: string;
  amenities?: string[];
  rules?: string[];
  price?: number;
  beds?: number;
  baths?: number;
  square_footage?: number;
  status?: 'active' | 'pending' | 'inactive' | 'suspended';
  views?: number;
  likes?: number;
  contacts?: number;
  created_at?: string;
  location_zone?: string;
  distance_to_beach?: number;
  distance_to_cowork?: number;
  furnished?: boolean;
  services_included?: string[];
  pet_friendly?: boolean;
  rental_duration_type?: string;
  lifestyle_compatible?: string[];
  property_description?: string;
  neighborhood_description?: string;
  house_rules?: string[];
  included_utilities?: string[];
  nearby_attractions?: string[];
  transportation_access?: string[];
  lease_terms?: string;
  deposit_amount?: number;
  move_in_date?: string;
  ideal_tenant_description?: string;
  listing_type?: string;
  availability_date?: string;
  is_featured?: boolean;
  view_count?: number;
  owner?: Profile;
}

export interface Swipe {
  id: string;
  user_id: string;
  target_id: string;
  target_type: 'listing' | 'profile';
  action: 'like' | 'pass' | 'superlike';
  created_at: string;
}

export interface Match {
  id: string;
  client_id: string;
  owner_id: string;
  listing_id?: string;
  client_liked_at?: string;
  owner_liked_at?: string;
  is_mutual?: boolean;
  conversation_started?: boolean;
  created_at: string;
  updated_at: string;
  match_score?: number;
  status?: string;
  client?: Profile;
  owner?: Profile;
  listing?: Listing;
}

export interface Message {
  id: string;
  sender_id: string;
  receiver_id: string;
  listing_id?: string;
  content: string;
  is_read?: boolean;
  created_at: string;
  sender?: Profile;
}

export interface Notification {
  id: string;
  user_id: string;
  type: string;
  message: string;
  read?: boolean;
  created_at: string;
}

// Auth helper functions
export const getCurrentUser = async () => {
  const { data: { user }, error } = await supabase.auth.getUser();
  if (error) throw error;
  return user;
};

export const getCurrentUserProfile = async () => {
  const user = await getCurrentUser();
  if (!user) return null;

  const { data: profile, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', user.id)
    .single();

  if (error) throw error;
  return profile as Profile;
};

export const createUserProfile = async (userId: string, profileData: Partial<Profile>) => {
  const { data, error } = await supabase
    .from('profiles')
    .insert({
      id: userId,
      ...profileData,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    })
    .select()
    .single();

  if (error) throw error;
  return data as Profile;
};

export const updateUserProfile = async (userId: string, updates: Partial<Profile>) => {
  const { data, error } = await supabase
    .from('profiles')
    .update({
      ...updates,
      updated_at: new Date().toISOString()
    })
    .eq('id', userId)
    .select()
    .single();

  if (error) throw error;
  return data as Profile;
};

// Role-based access helpers
export const checkUserRole = async (userId: string): Promise<'client' | 'owner' | 'broker' | 'admin' | null> => {
  const { data, error } = await supabase
    .from('profiles')
    .select('role')
    .eq('id', userId)
    .single();

  if (error) return null;
  return data.role;
};

export const isUserActive = async (userId: string): Promise<boolean> => {
  const { data, error } = await supabase
    .from('profiles')
    .select('is_active')
    .eq('id', userId)
    .single();

  if (error) return false;
  return data.is_active;
};